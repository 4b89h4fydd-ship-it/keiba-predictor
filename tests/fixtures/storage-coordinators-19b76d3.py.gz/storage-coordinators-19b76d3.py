def _history_worker(months_back: int | None=None):
    global _history_ready, _history_error
    time.sleep(float(os.getenv('HISTORY_START_DELAY_SEC', '0.15')))
    today = datetime.now().date()
    if months_back is None:
        months_back = max(2, min(8, int(os.getenv('NAR_HISTORY_WARM_MONTHS', '4'))))
    seen = set()
    jobs = []
    for y, m in [(today.year, today.month)] + list(iter_months_back(today, months_back - 1)):
        if (y, m) not in seen:
            jobs.append((y, m))
            seen.add((y, m))
    try:
        _, errors = _sync_nar_month_wave(jobs)
        _history_error = ' | '.join(errors)
    except Exception as exc:
        _history_error = str(exc)
    _history_ready = True

def ensure_history_async():
    global _history_started
    with _history_lock:
        if _history_started:
            return
        _history_started = True
        threading.Thread(target=_history_worker, daemon=True).start()

def _schedule_live_refresh(iso_date: str, force: bool=False):
    key = f'live:{iso_date}'
    now = int(time.time())
    with _live_refresh_lock:
        if key in _live_refresh_running or (not force and now - _live_refresh_last.get(key, 0) < 90):
            return
        _live_refresh_running.add(key)

    def worker():
        changed = False
        try:
            try:
                target = datetime.strptime(iso_date, '%Y-%m-%d').date()
                sync = NarSync()
                with _nar_sync_io_lock:
                    if iso_date == _today_iso():
                        sync.sync_daily(force=force)
                    else:
                        sync.sync_month(target.year, target.month, force=force)
                changed = True
            except Exception as exc:
                print(f'NAR background sync failed: {exc}')
            if changed:
                with _race_list_cache_lock:
                    [_race_list_cache.pop(k, None) for k in list(_race_list_cache) if k.startswith(iso_date + '|')]
        finally:
            with _live_refresh_lock:
                _live_refresh_running.discard(key)
                _live_refresh_last[key] = int(time.time())
    threading.Thread(target=worker, daemon=True).start()

def _schedule_central_refresh(iso_date: str, force: bool=False):
    now = int(time.time())
    with _central_refresh_lock:
        if iso_date in _central_refresh_running:
            return
        ttl = 90 if iso_date == _today_iso() else 3600
        if not force and now - _central_refresh_last.get(iso_date, 0) < ttl:
            return
        _central_refresh_running.add(iso_date)

    def worker():
        success = False
        try:
            if _clean(os.getenv('CENTRAL_FEED_URL', '')):
                rows = fetch_central_feed(iso_date)
            else:
                rows = fetch_jra_official(iso_date, lightweight=True)
                if not rows:
                    rows = _netkeiba_race_summaries(iso_date)
            if rows:
                st = CentralStore()
                try:
                    st.upsert(rows)
                finally:
                    st.conn.close()
                success = True
                with _race_list_cache_lock:
                    [_race_list_cache.pop(k, None) for k in list(_race_list_cache) if k.startswith(iso_date + '|')]
        except Exception as exc:
            print(f'Central async refresh failed: {exc}')
        finally:
            with _central_refresh_lock:
                _central_refresh_running.discard(iso_date)
                _central_refresh_last[iso_date] = int(time.time()) if success else max(0, int(time.time()) - 85)
    threading.Thread(target=worker, daemon=True).start()

def _commercial_collect_once():
    started = time.time()
    with _commercial_collector_lock:
        if _commercial_collector_state['running']:
            return
        _commercial_collector_state.update({'running': True, 'lastStart': started, 'lastError': '', 'hydrated': 0, 'diagnosed': 0})
    queued = ready = 0
    errs = []
    try:
        today = _today_iso()
        _schedule_live_refresh(today, False)
        _schedule_central_refresh(today, False)
        time.sleep(float(os.getenv('COMMERCIAL_LIST_SETTLE_SEC', '1.2')))
        rows = []
        try:
            rows.extend(nar_race_summaries(today))
        except Exception as exc:
            errs.append('NAR list: ' + str(exc))
        try:
            rows.extend(central_race_summaries(today, allow_network=False))
        except Exception as exc:
            errs.append('JRA list: ' + str(exc))
        nowj = _now_jst()
        now_min = nowj.hour * 60 + nowj.minute
        targets = _commercial_target_rows(rows, now_min)
        for idx, r in enumerate(targets):
            rid = str(r.get('id') or '')
            if not rid:
                continue
            d = _prepared_get_fresh(rid) or _racedb_get_fast(rid) or _fast_local_race_detail(rid)
            pm = (d or {}).get('preparedMeta') or {}
            if d and pm.get('diagnosisVersion') == PREDICTION_ENGINE_VERSION and pm.get('diagnosisReady'):
                ready += 1
                continue
            priority = 20 + idx
            _schedule_fast_card_refresh(rid, priority)
            queued += 1
        with _race_list_cache_lock:
            _race_list_cache.clear()
        _schedule_day_bundle_refresh(today, False)
    except Exception as exc:
        errs.append(str(exc))
    finally:
        finished = time.time()
        with _commercial_collector_lock:
            _commercial_collector_state.update({'running': False, 'lastFinish': finished, 'lastError': ' | '.join(errs[-6:]), 'hydrated': ready, 'diagnosed': ready, 'queued': queued, 'cycleSec': round(finished - started, 2)})

def _commercial_collector_loop():
    first_delay = float(os.getenv('COMMERCIAL_COLLECTOR_START_DELAY_SEC', '1.0'))
    interval = max(120, int(os.getenv('COMMERCIAL_COLLECTOR_INTERVAL_SEC', '180')))
    time.sleep(first_delay)
    while True:
        try:
            _commercial_collect_once()
        except Exception as exc:
            print('commercial collector cycle failed', exc)
        time.sleep(interval)

def _start_commercial_collector():
    enabled = str(os.getenv('ARVEXQ_COMMERCIAL_COLLECTOR', '1')).lower() in {'1', 'true', 'yes', 'on'}
    if enabled:
        threading.Thread(target=_commercial_collector_loop, daemon=True, name='arvexq-commercial-collector').start()

def _new_conn(path: Path):
    conn = sqlite3.connect(path, timeout=1.5)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute('PRAGMA query_only=ON')
        conn.execute('PRAGMA busy_timeout=1200')
    except Exception:
        pass
    return conn

def _patch_nar_environment(date: str, track: str, rows: list[dict], env: dict) -> list[str]:
    if not env:
        return []
    affected = []
    upcoming = _upcoming_rows(rows)
    if not upcoming:
        return affected
    conn = _new_conn(DB_PATH)
    try:
        with conn:
            for r in upcoming:
                no = int(r.get('raceNumber') or 0)
                if not no:
                    continue
                sets = []
                args = []
                if env.get('weather') not in (None, '', '不明'):
                    sets.append('weather=?')
                    args.append(env['weather'])
                if env.get('condition') not in (None, '', '不明'):
                    sets.append('condition=?')
                    args.append(env['condition'])
                if sets:
                    args.extend([track, date, no])
                    conn.execute('UPDATE races SET ' + ','.join(sets) + ' WHERE track=? AND date=? AND race_no=?', args)
                    affected.append(str(r.get('id') or f'nar-{date}-{track}-{no:02d}'))
                scratch_map = env.get('scratchMap') or {}
                if scratch_map and int(env.get('raceNo') or 0) == no:
                    for horse_no, status in scratch_map.items():
                        conn.execute('UPDATE entries SET status=? WHERE track=? AND date=? AND race_no=? AND horse_no=?', (str(status), track, date, no, int(horse_no)))
                    rid = str(r.get('id') or f'nar-{date}-{track}-{no:02d}')
                    if rid not in affected:
                        affected.append(rid)
    finally:
        conn.close()
    return affected

def _patch_central_environment(rows: list[dict], env_by_surface: dict, weather: str) -> list[str]:
    if not rows:
        return []
    upcoming = _upcoming_rows(rows)
    st = CentralStore()
    affected = []
    try:
        for r in upcoming:
            z = dict(r)
            changed = False
            if weather not in (None, '', '不明') and z.get('weather') != weather:
                z['weather'] = weather
                changed = True
            surf = str(z.get('surface') or '')
            cond = env_by_surface.get(surf) or (env_by_surface.get('芝') if surf == '障害' else None)
            if cond not in (None, '', '不明') and z.get('condition') != cond:
                z['condition'] = cond
                changed = True
            if changed:
                z['environmentMeta'] = {'source': 'JRA公式優先', 'updatedAtEpoch': int(time.time())}
                st.upsert([z])
                affected.append(str(z.get('id') or ''))
    finally:
        st.conn.close()
    return [x for x in affected if x]

def _refresh_track_environment(date: str, circuit: str, track: str, force: bool=False) -> dict:
    key = f'{date}|{circuit}|{track}'
    with _environment_lock:
        state = _environment_state.get(key) or {}
        if state.get('running'):
            return dict(state)
        if not force and int(time.time()) - int(state.get('updatedAtEpoch') or 0) < 25:
            return dict(state)
        _environment_state[key] = {'running': True, 'updatedAtEpoch': int(state.get('updatedAtEpoch') or 0), 'changed': 0, 'error': ''}
    affected = []
    error = ''
    try:
        rows = nar_race_summaries(date) if circuit == '地方' else central_race_summaries(date, allow_network=False)
        rows = [r for r in rows if str(r.get('track') or '') == str(track)]
        if not rows:
            return {'running': False, 'changed': 0}
        if circuit == '地方':
            reps = _upcoming_rows(rows)
            rep = reps[0] if reps else rows[0]
            env = _nar_fetch_environment(track, date, int(rep.get('raceNumber') or 0))
            if env:
                affected = _patch_nar_environment(date, track, rows, env)
        else:
            reps = _upcoming_rows(rows)
            by_surface = {}
            weather = '不明'
            for surf in ('芝', 'ダート', '障害'):
                cand = next((r for r in reps if str(r.get('surface') or '') == surf), None)
                if not cand:
                    continue
                env = _jra_fetch_environment(cand)
                if env.get('weather') not in (None, '', '不明'):
                    weather = env['weather']
                if env.get('condition') not in (None, '', '不明'):
                    by_surface[surf] = env['condition']
                for k, v in (env.get('surfaceConditions') or {}).items():
                    if v not in (None, '', '不明'):
                        by_surface[k] = v
            affected = _patch_central_environment(rows, by_surface, weather)
        if affected:
            with _race_list_cache_lock:
                [_race_list_cache.pop(k, None) for k in list(_race_list_cache) if k.startswith(date + '|')]
            for rid in affected:
                try:
                    _build_fast_diagnosis_snapshot(rid, allow_network=False, deep_context=False)
                except Exception as exc:
                    print('environment diagnosis rebuild failed', rid, exc)
    except Exception as exc:
        error = str(exc)
        print('track environment refresh failed', date, circuit, track, exc)
    finally:
        with _environment_lock:
            _environment_state[key] = {'running': False, 'updatedAtEpoch': int(time.time()), 'changed': len(affected), 'error': error}
    return dict(_environment_state.get(key) or {})

def _schedule_track_environment(date: str, circuit: str, track: str, force: bool=False) -> None:
    key = f'{date}|{circuit}|{track}'
    with _environment_lock:
        if key in _environment_running:
            return
        state = _environment_state.get(key) or {}
        if not force and int(time.time()) - int(state.get('updatedAtEpoch') or 0) < 25:
            return
        _environment_running.add(key)

    def worker():
        try:
            _refresh_track_environment(date, circuit, track, force)
        finally:
            with _environment_lock:
                _environment_running.discard(key)
    threading.Thread(target=worker, daemon=True, name='env-' + track).start()

def _environment_cycle():
    date = _today_iso()
    rows = []
    try:
        rows.extend(nar_race_summaries(date))
    except Exception:
        pass
    try:
        rows.extend(central_race_summaries(date, allow_network=False))
    except Exception:
        pass
    groups = []
    seen = set()
    for r in rows:
        key = (str(r.get('circuit') or ''), str(r.get('track') or ''))
        if not key[0] or not key[1] or key[1] == '帯広' or (key in seen):
            continue
        seen.add(key)
        groups.append(key)
    for circuit, track in groups:
        _schedule_track_environment(date, circuit, track, False)

def _environment_loop():
    time.sleep(float(os.getenv('ENVIRONMENT_START_DELAY_SEC', '0.8')))
    while True:
        try:
            _environment_cycle()
        except Exception as exc:
            print('environment cycle failed', exc)
        time.sleep(max(30, int(os.getenv('ENVIRONMENT_REFRESH_SEC', '45'))))

def _start_environment_collector():
    enabled = str(os.getenv('ARVEXQ_ENVIRONMENT_COLLECTOR', '1')).lower() in {'1', 'true', 'yes', 'on'}
    if enabled:
        threading.Thread(target=_environment_loop, daemon=True, name='arvexq-environment').start()

def _data_core_active_horses(detail: dict) -> list[dict]:
    return [h for h in detail.get('horses') or [] if isinstance(h, dict) and (not h.get('scratched')) and (int(h.get('horseNumber') or 0) > 0)]

def _data_core_result_due(detail: dict) -> bool:
    try:
        if str(detail.get('date') or '') != _today_iso():
            return True
        st = _race_minutes_server(detail)
        if st >= 9999:
            return False
        now = _now_jst()
        return now.hour * 60 + now.minute >= st + 2
    except Exception:
        return False

def _data_core_health(detail: dict | None) -> dict:
    d = detail if isinstance(detail, dict) else {}
    horses = _data_core_active_horses(d)
    total = len(horses)
    field_size = max(total, int(d.get('fieldSize') or 0))
    named = sum((1 for h in horses if str(h.get('name') or '').strip() and str(h.get('jockey') or '').strip()))
    card_pct = int(round(100 * named / max(1, field_size))) if field_size else 0
    card_ready = bool(field_size >= 2 and named >= max(2, field_size - 1))
    hist_counts = []
    for h in horses:
        if h.get('debutNoHistory'):
            hist_counts.append(5)
        else:
            runs = [x for x in h.get('recentRaces') or h.get('allPastRuns') or [] if isinstance(x, dict)]
            hist_counts.append(min(5, len(runs)))
    hist_total = max(1, total * 5)
    hist_points = sum(hist_counts)
    hist_pct = int(round(100 * hist_points / hist_total)) if total else 0
    history_ready = bool(total and all((x >= 5 for x in hist_counts)))
    real_odds = []
    weights = []
    for h in horses:
        try:
            odd = float(h.get('winOdds') or 0)
        except Exception:
            odd = 0.0
        real_odds.append(bool(odd > 1 and (not h.get('oddsForecast')) and (not re.search('予想|forecast', str(h.get('oddsSource') or ''), re.I))))
        try:
            bw = int(h.get('bodyWeight') or 0)
        except Exception:
            bw = 0
        weights.append(bool(250 <= bw <= 800))
    odds_pct = int(round(100 * sum(real_odds) / max(1, total))) if total else 0
    body_pct = int(round(100 * sum(weights) / max(1, total))) if total else 0
    clock_state, minutes_to_post = _prediction_clock_state(d)
    is_today = str(d.get('date') or '') == _today_iso()
    odds_due = bool(not is_today or clock_state == 'started' or minutes_to_post is None or (minutes_to_post <= 360) or any(real_odds))
    body_due = bool(not is_today or clock_state == 'started' or minutes_to_post is None or (minutes_to_post <= 120) or any(weights))
    weather = str(d.get('weather') or '').strip()
    condition = str(d.get('condition') or '').strip()
    env_ready = weather not in ('', '不明', '—') and condition not in ('', '不明', '—')
    env_pct = (50 if weather not in ('', '不明', '—') else 0) + (50 if condition not in ('', '不明', '—') else 0)
    result = d.get('result') if isinstance(d.get('result'), dict) else {}
    finishers = [x for x in result.get('finishers') or [] if isinstance(x, dict)]
    ranks = {int(x.get('finish') or 0) for x in finishers}
    result_ready = all((x in ranks for x in (1, 2, 3)))
    final = bool(str(result.get('status') or '') == '確定' or _snapshot_final(d))
    payouts = result.get('payouts') if isinstance(result.get('payouts'), list) else []
    payouts_ready = bool(payouts)
    due = _data_core_result_due(d)
    pm = d.get('preparedMeta') if isinstance(d.get('preparedMeta'), dict) else {}
    analysis_ready = bool(pm.get('diagnosisReady') and pm.get('diagnosisVersion') == PREDICTION_ENGINE_VERSION)
    srcs = [str(x) for x in d.get('dataSources') or [] if x]
    default_source = ' / '.join(srcs[:4]) or str(d.get('source') or '')

    def rec(status, pct, source='', note=''):
        return {'status': status, 'completeness': max(0, min(100, int(pct))), 'source': source or default_source, 'note': note}
    return {'card': rec('ready' if card_ready else 'missing', card_pct, note=f'{named}/{field_size or total}頭 基本項目'), 'history': rec('ready' if history_ready else 'partial' if hist_points else 'missing', hist_pct, note=f'{hist_points}/{(total * 5 if total else 0)}走'), 'odds': rec('ready' if total and all(real_odds) else ('partial' if any(real_odds) else 'missing') if odds_due else 'not_due', odds_pct, str(d.get('oddsSource') or default_source), f'{sum(real_odds)}/{total}頭 実単勝' + (' / 取得時間前' if not odds_due else '')), 'body_weight': rec('ready' if total and all(weights) else ('partial' if any(weights) else 'missing') if body_due else 'not_due', body_pct, note=f'{sum(weights)}/{total}頭 現在馬体重' + (' / 発表時間前' if not body_due else '')), 'environment': rec('ready' if env_ready else 'partial' if env_pct else 'missing', env_pct, note=f"天候 {weather or '—'} / 馬場 {condition or '—'}"), 'result': rec('ready' if result_ready else 'pending' if due else 'not_due', 100 if result_ready else 0, str(result.get('source') or default_source), '上位3頭' if result_ready else '確定待ち'), 'payouts': rec('ready' if payouts_ready else 'pending' if final else 'not_due', 100 if payouts_ready else 0, str(result.get('payoutSource') or default_source), f'{len(payouts)}件' if payouts_ready else '確定待ち'), 'analysis': rec('ready' if analysis_ready else 'missing', 100 if analysis_ready else 0, note=str(pm.get('diagnosisVersion') or ''))}

def _data_core_health_hash(field_key: str, item: dict) -> str:
    raw = json.dumps([field_key, item.get('status'), item.get('completeness'), item.get('source'), item.get('note')], ensure_ascii=False, separators=(',', ':'))
    return hashlib.sha1(raw.encode('utf-8', 'ignore')).hexdigest()

def _data_core_store_health(detail: dict | None, attempted: set[str] | None=None, source_hint: str='') -> dict:
    if not isinstance(detail, dict) or not detail.get('id'):
        return {}
    rid = str(detail.get('id'))
    health = _data_core_health(detail)
    now = int(time.time())
    attempted = attempted or set()
    conn = sqlite3.connect(RACEDB.path, timeout=3)
    try:
        for key, item in health.items():
            src = str(item.get('source') or source_hint or '')[:180]
            status = str(item.get('status') or 'missing')
            pct = int(item.get('completeness') or 0)
            note = str(item.get('note') or '')[:400]
            vh = _data_core_health_hash(key, item)
            row = conn.execute('SELECT attempts FROM field_state WHERE race_id=? AND field_key=?', (rid, key)).fetchone()
            attempts = int(row[0] or 0) if row else 0
            if key in attempted and status != 'ready':
                attempts += 1
            conn.execute("INSERT INTO field_state(race_id,field_key,status,completeness,source,updated_at,last_attempt_at,attempts,note,value_hash)\n                            VALUES(?,?,?,?,?,?,?,?,?,?)\n                            ON CONFLICT(race_id,field_key) DO UPDATE SET status=excluded.status,completeness=excluded.completeness,\n                            source=CASE WHEN excluded.source<>'' THEN excluded.source ELSE field_state.source END,\n                            updated_at=excluded.updated_at,last_attempt_at=excluded.last_attempt_at,attempts=excluded.attempts,note=excluded.note,value_hash=excluded.value_hash", (rid, key, status, pct, src, now, now if key in attempted else 0, attempts, note, vh))
        conn.commit()
    finally:
        conn.close()
    return health

def _data_core_record_run(run_id: str, race_id: str, started: int, status: str, attempted: set[str], before: dict, after: dict, note: str=''):
    conn = sqlite3.connect(RACEDB.path, timeout=3)
    try:
        conn.execute('INSERT OR REPLACE INTO collector_runs(run_id,race_id,started_at,finished_at,status,attempted_fields,before_json,after_json,note)\n                        VALUES(?,?,?,?,?,?,?,?,?)', (run_id, race_id, started, int(time.time()), status, json.dumps(sorted(attempted), ensure_ascii=False), json.dumps(before, ensure_ascii=False, separators=(',', ':')), json.dumps(after, ensure_ascii=False, separators=(',', ':')), str(note or '')[:600]))
        conn.commit()
    finally:
        conn.close()

def _data_core_snapshot(race_id: str) -> dict | None:
    return _prepared_get_fresh(race_id) or _racedb_get_fast(race_id) or _fast_local_race_detail(race_id)

def _data_core_refresh_race(race_id: str, force: bool=False) -> dict:
    rid = str(race_id or '')
    if not rid:
        return {'raceId': rid, 'ok': False, 'error': 'empty race id'}
    with _data_core_lock:
        if rid in _data_core_running:
            d = _data_core_snapshot(rid)
            return {'raceId': rid, 'ok': True, 'running': True, 'health': _data_core_health(d)}
        _data_core_running.add(rid)
    started = int(time.time())
    run_id = f'dc-{started}-{hashlib.sha1(rid.encode()).hexdigest()[:8]}'
    attempted = set()
    errors = []
    try:
        d = _data_core_snapshot(rid)
        before = _data_core_health(d)
        if force or before.get('card', {}).get('status') != 'ready':
            attempted.add('card')
            try:
                _hydrate_fast_card_now(rid, deep_history=False)
            except Exception as exc:
                errors.append('card:' + str(exc))
            d = _data_core_snapshot(rid)
        h = _data_core_health(d)
        if str((d or {}).get('date') or '') == _today_iso() and (force or h.get('odds', {}).get('status') != 'ready' or h.get('body_weight', {}).get('status') != 'ready'):
            attempted.update({'odds', 'body_weight'})
            try:
                odds_refresh(rid, 1)
            except Exception as exc:
                errors.append('live:' + str(exc))
            d = _data_core_snapshot(rid)
        h = _data_core_health(d)
        if force or h.get('environment', {}).get('status') != 'ready':
            attempted.add('environment')
            try:
                if rid.startswith('jra-'):
                    fresh = central_race_detail(rid)
                    if fresh:
                        base = d or fresh
                        for k in ('weather', 'condition', 'title', 'distance', 'surface', 'startTime', 'scheduledStartTime'):
                            if fresh.get(k) not in (None, '', 0, '不明'):
                                base[k] = fresh.get(k)
                        RACEDB.upsert_race(base)
                        PREPARED_STORE.put(base, force=True)
                        d = base
                else:
                    _schedule_track_environment(str((d or {}).get('date') or _today_iso()), str((d or {}).get('circuit') or '地方'), str((d or {}).get('track') or ''), True)
            except Exception as exc:
                errors.append('env:' + str(exc))
        h = _data_core_health(d)
        if force or h.get('history', {}).get('status') != 'ready':
            attempted.add('history')
            try:
                if rid.startswith('jra-'):
                    _start_central_history_search(rid, str((d or {}).get('date') or _today_iso()), force=bool(force))
                else:
                    names = [str(x.get('name') or '') for x in (d or {}).get('horses') or [] if x.get('name')]
                    if names:
                        _start_race_history_search(rid, str((d or {}).get('date') or _today_iso()), names, force=bool(force))
            except Exception as exc:
                errors.append('history:' + str(exc))
        h = _data_core_health(d)
        if _data_core_result_due(d or {}) and (force or h.get('result', {}).get('status') != 'ready'):
            attempted.add('result')
            try:
                _refresh_result_fast(rid)
            except Exception as exc:
                errors.append('result:' + str(exc))
            d = _data_core_snapshot(rid)
        h = _data_core_health(d)
        if h.get('result', {}).get('status') == 'ready' and (force or h.get('payouts', {}).get('status') != 'ready'):
            attempted.add('payouts')
            try:
                payout_refresh(rid)
            except Exception as exc:
                errors.append('payouts:' + str(exc))
            d = _data_core_snapshot(rid)
        h = _data_core_health(d)
        if force or h.get('analysis', {}).get('status') != 'ready':
            attempted.add('analysis')
            try:
                _build_fast_diagnosis_snapshot(rid, allow_network=False, deep_context=False)
            except Exception as exc:
                errors.append('analysis:' + str(exc))
            d = _data_core_snapshot(rid)
        after = _data_core_store_health(d, attempted, 'ARVEXQ Data Core')
        if isinstance(d, dict) and d.get('id'):
            d['dataCoreHealth'] = after
            d['dataCoreVersion'] = ARVEXQ_DATA_CORE_VERSION
            d['dataCoreUpdatedAt'] = int(time.time())
            try:
                RACEDB.upsert_race(d)
                PREPARED_STORE.put(d, force=True)
            except Exception as exc:
                errors.append('persist-health:' + str(exc))
        _data_core_record_run(run_id, rid, started, 'partial' if errors else 'ok', attempted, before, after, ' | '.join(errors[-5:]))
        return {'raceId': rid, 'ok': not errors, 'attempted': sorted(attempted), 'health': after, 'errors': errors[-5:], 'version': ARVEXQ_DATA_CORE_VERSION}
    finally:
        with _data_core_lock:
            _data_core_running.discard(rid)

def _data_core_day_rows(date: str) -> list[dict]:
    try:
        return _bootstrap_rows_local(date)
    except Exception:
        return []

def _data_core_day_status(date: str, circuit: str='') -> dict:
    rows = [r for r in _data_core_day_rows(date) if not circuit or str(r.get('circuit') or '') == str(circuit)]
    ids = [str(r.get('id') or '') for r in rows if r.get('id')]
    by = {rid: {} for rid in ids}
    if ids:
        conn = sqlite3.connect(RACEDB.path, timeout=3)
        conn.row_factory = sqlite3.Row
        try:
            marks = ','.join(('?' for _ in ids))
            for r in conn.execute(f'SELECT * FROM field_state WHERE race_id IN ({marks})', ids).fetchall():
                by.setdefault(str(r['race_id']), {})[str(r['field_key'])] = dict(r)
        finally:
            conn.close()
    fields = {k: {'ready': 0, 'partial': 0, 'missing': 0, 'pending': 0, 'not_due': 0} for k in DATA_CORE_FIELDS}
    ready_races = 0
    race_rows = []
    for r in rows:
        rid = str(r.get('id') or '')
        st = by.get(rid) or {}
        if not st:
            h = _data_core_health(_data_core_snapshot(rid))
            st = {k: {'status': v.get('status'), 'completeness': v.get('completeness'), 'source': v.get('source'), 'note': v.get('note')} for k, v in h.items()}
        for k in DATA_CORE_FIELDS:
            status = str((st.get(k) or {}).get('status') or 'missing')
            fields[k][status if status in fields[k] else 'missing'] += 1
        essential = ('card', 'history', 'odds', 'body_weight', 'environment', 'analysis')
        ready = all((str((st.get(k) or {}).get('status') or '') in ({'ready', 'not_due'} if k in {'odds', 'body_weight'} else {'ready'}) for k in essential))
        if ready:
            ready_races += 1
        race_rows.append({'id': rid, 'track': r.get('track'), 'raceNumber': r.get('raceNumber'), 'startTime': r.get('startTime'), 'ready': ready, 'fields': st})
    return {'version': ARVEXQ_DATA_CORE_VERSION, 'date': date, 'circuit': circuit, 'raceCount': len(rows), 'readyRaceCount': ready_races, 'fields': fields, 'races': race_rows}

def _data_core_cycle():
    global _data_core_state
    with _data_core_lock:
        if _data_core_state.get('running'):
            return
        _data_core_state.update({'running': True, 'lastStart': int(time.time()), 'checked': 0, 'refreshed': 0, 'error': ''})
    checked = refreshed = 0
    errors = []
    try:
        rows = _data_core_day_rows(_today_iso())
        nowj = _now_jst()
        nowm = nowj.hour * 60 + nowj.minute
        candidates = []
        for r in rows:
            rid = str(r.get('id') or '')
            if not rid:
                continue
            d = _data_core_snapshot(rid)
            h = _data_core_health(d)
            checked += 1
            _data_core_store_health(d, set(), 'local') if d else None
            needed = [k for k in ('card', 'history', 'odds', 'body_weight', 'environment', 'analysis') if h.get(k, {}).get('status') not in {'ready', 'not_due'}]
            if _data_core_result_due(d or r) and h.get('result', {}).get('status') != 'ready':
                needed.append('result')
            if h.get('result', {}).get('status') == 'ready' and h.get('payouts', {}).get('status') != 'ready':
                needed.append('payouts')
            if needed:
                st = _race_minutes_server(r)
                dist = abs(st - nowm) if st < 9999 else 9999
                candidates.append((dist, st, rid, needed))
        candidates.sort(key=lambda x: (x[0], x[1]))
        targets = candidates[:max(1, int(os.getenv('ARVEXQ_DATA_CORE_BATCH', '16')))]
        workers = max(1, min(8, len(targets))) if targets else 0
        if workers:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                for z in pool.map(lambda x: _data_core_refresh_race(x[2], False), targets):
                    refreshed += 1
                    if not z.get('ok') and z.get('errors'):
                        errors.extend(z.get('errors') or [])
    except Exception as exc:
        errors.append(str(exc))
    finally:
        with _data_core_lock:
            _data_core_state.update({'running': False, 'lastFinish': int(time.time()), 'checked': checked, 'refreshed': refreshed, 'error': ' | '.join(errors[-5:])})

def _data_core_loop():
    time.sleep(float(os.getenv('ARVEXQ_DATA_CORE_START_DELAY_SEC', '1.2')))
    while True:
        try:
            _data_core_cycle()
        except Exception as exc:
            print('ARVEXQ Data Core cycle failed', exc)
        time.sleep(max(10, int(os.getenv('ARVEXQ_DATA_CORE_LOOP_SEC', '12'))))

def _start_data_core_collector():
    enabled = str(os.getenv('ARVEXQ_DATA_CORE', '1')).lower() in {'1', 'true', 'yes', 'on'}
    if enabled:
        threading.Thread(target=_data_core_loop, daemon=True, name='arvexq-data-core').start()

def _restore_saved_odds(detail: dict) -> dict:
    """Display-only odds must survive diagnosis/history/environment snapshot rebuilds."""
    if not isinstance(detail, dict):
        return detail
    race_id = str(detail.get('id') or '')
    if not race_id:
        return detail
    rows = []
    try:
        rows = RACEDB.odds_latest(race_id) or []
    except Exception:
        rows = []
    if not rows:
        try:
            previous, _ = PREPARED_STORE.get(race_id)
            if previous:
                rows = [{'horseNumber': h.get('horseNumber'), 'winOdds': h.get('winOdds'), 'popularity': h.get('popularity'), 'oddsSource': h.get('oddsSource') or previous.get('oddsSource')} for h in previous.get('horses') or [] if h.get('winOdds') not in (None, '')]
                if rows:
                    detail['oddsUpdatedAt'] = previous.get('oddsUpdatedAt') or detail.get('oddsUpdatedAt')
                    detail['oddsSource'] = previous.get('oddsSource') or detail.get('oddsSource')
        except Exception:
            pass
    if not rows:
        return detail
    by = {int(h.get('horseNumber') or 0): h for h in detail.get('horses') or []}
    latest = 0
    source = ''
    for z in rows:
        no = int(z.get('horseNumber') or 0)
        h = by.get(no)
        if not h:
            continue
        for k in ('winOdds', 'popularity'):
            if z.get(k) not in (None, ''):
                h[k] = z.get(k)
        if z.get('oddsSource'):
            h['oddsSource'] = z.get('oddsSource')
            source = z.get('oddsSource')
        latest = max(latest, int(z.get('capturedAt') or 0))
    if source:
        detail['oddsSource'] = source
    if latest:
        detail['oddsUpdatedAt'] = datetime.fromtimestamp(latest, ZoneInfo('Asia/Tokyo')).strftime('%H:%M:%S')
    return detail

def _prepared_ttl(detail: dict) -> int:
    return int(os.getenv('PREPARED_TODAY_TTL_SEC', '45')) if str(detail.get('date') or '') == _today_iso() else int(os.getenv('PREPARED_ARCHIVE_TTL_SEC', '21600'))

def _prepared_get_fresh(race_id: str) -> dict | None:
    detail, updated = PREPARED_STORE.get(race_id)
    if not detail or not updated or (not _racedb_snapshot_usable(detail)):
        return None
    if (detail.get('preparedMeta') or {}).get('fastPartial'):
        return detail
    if (detail.get('aiEvaluation') or {}).get('version') != AI_EVALUATION_VERSION:
        detail = _precompute_detail_metrics(_strip_excluded(detail))
    detail = _ensure_race_volatility(detail)
    detail = _restore_saved_odds(detail)
    try:
        detail['dataCoreHealth'] = _data_core_health(detail)
        detail['dataCoreVersion'] = ARVEXQ_DATA_CORE_VERSION
    except Exception:
        pass
    return detail

def _refresh_result_fast(race_id: str) -> dict | None:
    return _acq_snapshots_results._refresh_result_fast(race_id, _attach_nar_payouts=_attach_nar_payouts, _compact_display_snapshot=_compact_display_snapshot, _fast_local_race_detail=_fast_local_race_detail, _jra_find_cname=_jra_find_cname, _jra_parse_result=_jra_parse_result, _jra_result_cname_from_card=_jra_result_cname_from_card, _merge_result_fields=_merge_result_fields, _nar_official_result_fast=_nar_official_result_fast, _netkeiba_current_result=_netkeiba_current_result, _prepared_get_fresh=_prepared_get_fresh, _race_should_have_result=_race_should_have_result, _racedb_get_fast=_racedb_get_fast, _store_fast_snapshot=_store_fast_snapshot, central_race_detail=central_race_detail, nar_race_detail=nar_race_detail)

def _prepare_race_snapshot(race_id: str, force: bool=False, manual: bool=False) -> dict | None:
    hit = _prepared_get_fresh(race_id) or _racedb_get_fast(race_id)
    if hit and (str(hit.get('date') or '') < _today_iso() or _snapshot_final(hit)) and (not force):
        return hit
    if hit and (not force):
        return hit
    if manual and race_id.startswith('nar-'):
        match = re.match('^nar-(\\d{4}-\\d{2}-\\d{2})-', race_id)
        if match:
            target = datetime.strptime(match.group(1), '%Y-%m-%d')
            sync = NarSync()
            try:
                with _nar_sync_io_lock:
                    if match.group(1) == _today_iso():
                        sync.sync_daily(force=True)
                    else:
                        sync.sync_month(target.year, target.month, force=True)
            finally:
                sync.store.conn.close()
    detail = nar_race_detail(race_id) if race_id.startswith('nar-') else central_race_detail(race_id)
    if not detail:
        return None
    horses = detail.get('horses') if isinstance(detail.get('horses'), list) else []
    if not race_id.startswith('nar-') and int(detail.get('fieldSize') or 0) > 0 and (not horses) and (not detail.get('result')):
        return None
    if race_id.startswith('nar-'):
        detail = _attach_nar_payouts(detail)
    if hit and hit.get('analysis'):
        detail['analysis'] = hit['analysis']
    detail = _strip_excluded(_apply_enrichment(race_id, detail))
    detail = _attach_stored_career(detail)
    detail = _precompute_detail_metrics(_attach_evaluation_context(detail))
    detail = _restore_saved_odds(detail)
    detail.setdefault('preparedMeta', {}).pop('fastPartial', None)
    detail.setdefault('historySearch', {'status': 'prepared', 'monthsDone': 0, 'maxMonths': 0, 'coverage': {'totalHorses': len(detail.get('horses', [])), 'totalRuns': sum((len(h.get('recentRaces') or []) for h in detail.get('horses', [])))}, 'error': '', 'source': detail.get('source') or 'prepared'})
    try:
        RACEDB.upsert_race(detail)
        _schedule_full_history_harvest(detail)
    except Exception as exc:
        print('RaceDB snapshot write failed', race_id, exc)
    PREPARED_STORE.put(detail, force=bool(manual or force))
    display = _compact_display_snapshot(detail)
    if detail.get('date') == _today_iso() and (not _snapshot_final(detail)):
        _schedule_detail_background_jobs(race_id, detail)
    return display

def _prewarm_sort_key(row: dict, date: str) -> tuple:
    t = str(row.get('startTime') or '')
    try:
        hh, mm = t.split(':', 1)
        m = int(hh) * 60 + int(mm[:2])
    except Exception:
        m = 9999
    if date == _today_iso():
        now = _now_jst().hour * 60 + _now_jst().minute
        return (0 if m >= now else 1, m if m >= now else m + 1440, str(row.get('track') or ''), int(row.get('raceNumber') or 0))
    return (0, m, str(row.get('track') or ''), int(row.get('raceNumber') or 0))

def _schedule_prewarm(rows: list[dict], date: str, circuit: str='') -> None:
    ordered = [r for r in sorted(rows, key=lambda x: _prewarm_sort_key(x, date)) if r.get('id') and (not circuit or r.get('circuit') == circuit)]
    max_races = max(1, int(os.getenv('PREWARM_MAX_RACES', '36')))
    ordered = ordered[:max_races]
    if not ordered:
        return
    key = f"{date}|{circuit or 'all'}"
    with _prewarm_lock:
        if key in _prewarm_running:
            return
        _prewarm_running.add(key)
        _prewarm_state[key] = {'running': True, 'done': 0, 'total': len(ordered), 'last': int(time.time()), 'errors': 0}

    def worker():
        done = errs = 0
        workers = max(1, min(int(os.getenv('PREWARM_WORKERS', '2')), len(ordered)))
        deep = max(0, int(os.getenv('PREWARM_DEEP_RACES', '3')))

        def one(ix_row):
            ix, row = ix_row
            rid = str(row.get('id') or '')
            detail = _prepared_get_fresh(rid) or _racedb_get_fast(rid) or _fast_local_race_detail(rid)
            if detail:
                if not (_prepared_get_fresh(rid) or _racedb_get_fast(rid)):
                    _store_fast_snapshot(detail)
            else:
                _schedule_fast_card_refresh(rid)
            return (rid, detail)
        try:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = [pool.submit(one, x) for x in enumerate(ordered)]
                for fut in as_completed(futures):
                    try:
                        _, detail = fut.result()
                        if detail:
                            done += 1
                        else:
                            errs += 1
                    except Exception as exc:
                        errs += 1
                        print('prewarm failed', exc)
                    with _prewarm_lock:
                        _prewarm_state[key] = {'running': True, 'done': done, 'total': len(ordered), 'last': int(time.time()), 'errors': errs}
        finally:
            with _prewarm_lock:
                _prewarm_running.discard(key)
                _prewarm_state[key] = {'running': False, 'done': done, 'total': len(ordered), 'last': int(time.time()), 'errors': errs}
    threading.Thread(target=worker, daemon=True).start()

def _ensure_detail_background_jobs(race_id: str, detail: dict) -> None:
    if detail.get('date') != _today_iso() or _snapshot_final(detail):
        return
    try:
        es = _enrichment_status(race_id)
        if es.get('status') in {'idle', 'unavailable'}:
            _start_enrichment(race_id, detail)
    except Exception as exc:
        print('prepared enrichment schedule failed', race_id, exc)
    try:
        if race_id.startswith('nar-'):
            names = [str(h.get('name') or '') for h in detail.get('horses', []) if h.get('name')]
            cov = _history_counts(names, detail.get('date') or '9999-12-31')
            if _race_history_status(race_id) is None and (not _history_is_enough(cov, 0)):
                _start_race_history_search(race_id, detail.get('date') or _today_iso(), names)
        else:
            cov = _central_detail_coverage(detail)
            total = int(cov.get('totalHorses') or 0)
            resolved = int(cov.get('horsesResolved') or cov.get('horsesWith5Plus') or 0)
            if detail.get('analysisMode') != '新馬' and _race_history_status(race_id) is None and (not assess_career_readiness(detail).get('ready')):
                _start_central_history_search(race_id, detail.get('date') or _today_iso())
    except Exception as exc:
        print('prepared history schedule failed', race_id, exc)

def _schedule_detail_background_jobs(race_id: str, detail: dict) -> None:
    threading.Thread(target=_ensure_detail_background_jobs, args=(race_id, detail), daemon=True).start()

def _store_fast_snapshot(detail: dict) -> None:
    if not detail or not _racedb_snapshot_usable(detail):
        return
    detail = _restore_saved_odds(detail)
    try:
        PREPARED_STORE.put(detail, force=True)
    except Exception as exc:
        print('fast prepared save failed', detail.get('id'), exc)
    try:
        RACEDB.upsert_race(detail)
    except Exception as exc:
        print('fast RaceDB save failed', detail.get('id'), exc)

def _ensure_fast_card_workers():
    global _fast_card_workers_started
    with _fast_card_cv:
        if _fast_card_workers_started:
            return
        _fast_card_workers_started = True
        workers = max(1, min(6, int(os.getenv('FAST_CARD_WORKERS', '4'))))
        for idx in range(workers):
            threading.Thread(target=_fast_card_worker, daemon=True, name=f'fast-card-worker-{idx + 1}').start()

def _queue_fast_card(race_id: str, priority: int=50):
    if not race_id:
        return
    _ensure_fast_card_workers()
    with _fast_card_cv:
        if race_id in _fast_card_pending or race_id in _fast_card_running:
            return
        _fast_card_pending.add(race_id)
        _fast_card_queue.append((int(priority), time.time(), race_id))
        _fast_card_queue.sort(key=lambda x: (x[0], x[1]))
        _fast_card_cv.notify()

def _fast_card_worker():
    while True:
        with _fast_card_cv:
            while not _fast_card_queue:
                _fast_card_cv.wait()
            priority, _, race_id = _fast_card_queue.pop(0)
            _fast_card_pending.discard(race_id)
            _fast_card_running.add(race_id)
        try:
            deep = priority <= 10
            _hydrate_fast_card_now(race_id, deep_history=deep)
            try:
                _build_fast_diagnosis_snapshot(race_id, allow_network=False, deep_context=deep)
            except Exception as exc:
                print('fast diagnosis after card failed', race_id, exc)
        except Exception as exc:
            print('fast card worker failed', race_id, exc)
        finally:
            with _fast_card_cv:
                _fast_card_running.discard(race_id)

def _schedule_fast_card_refresh(race_id: str, priority: int=50) -> None:
    _queue_fast_card(race_id, priority)

def _schedule_racedb_snapshot_refresh(race_id: str) -> None:
    with _racedb_refresh_lock:
        if race_id in _racedb_refresh_running:
            return
        _racedb_refresh_running.add(race_id)

    def worker():
        try:
            fresh = _prepare_race_snapshot(race_id, True)
            if fresh:
                _ensure_detail_background_jobs(race_id, fresh)
        except Exception as exc:
            print('RaceDB refresh failed', race_id, exc)
        finally:
            with _racedb_refresh_lock:
                _racedb_refresh_running.discard(race_id)
    threading.Thread(target=worker, daemon=True).start()

def _racedb_get_fast(race_id: str) -> dict | None:
    try:
        detail, updated = RACEDB.get_race(race_id)
    except Exception:
        return None
    if not detail or not _racedb_snapshot_usable(detail):
        return None
    if (detail.get('preparedMeta') or {}).get('fastPartial'):
        return detail
    if (detail.get('aiEvaluation') or {}).get('version') != AI_EVALUATION_VERSION:
        detail = _precompute_detail_metrics(_strip_excluded(detail))
    detail = _ensure_race_volatility(detail)
    detail = _restore_saved_odds(detail)
    return detail

def _bootstrap_rows_local(date: str) -> list[dict]:
    raw = races(date, '', 0, 0)
    rows = raw.get('races', []) if isinstance(raw, dict) else list(raw or [])
    out = []
    seen = set()
    for r in rows:
        rid = str(r.get('id') or '')
        if not rid or rid in seen:
            continue
        seen.add(rid)
        out.append(r)
    out.sort(key=lambda r: (str(r.get('circuit') or ''), str(r.get('track') or ''), int(r.get('raceNumber') or 0)))
    return out

def _bootstrap_sources_running(date: str) -> bool:
    running = False
    try:
        with _live_refresh_lock:
            running = running or f'live:{date}' in _live_refresh_running
    except Exception:
        pass
    try:
        running = running or bool(_central_refresh_status(date).get('running'))
    except Exception:
        pass
    return bool(running)

def _bootstrap_analysis_ready(d: dict | None) -> bool:
    """Diagnosis readiness is tracked separately and must never block site display."""
    if not _bootstrap_display_ready(d):
        return False
    if _snapshot_final(d):
        return True
    pm = d.get('preparedMeta') or {}
    return bool(pm.get('diagnosisReady') and pm.get('diagnosisVersion') == PREDICTION_ENGINE_VERSION)

def _bootstrap_detail_local(race_id: str, force_hydrate: bool=False) -> dict | None:
    """Fast local snapshot for day bundles. Heavy diagnosis work is background-only."""
    d = _prepared_get_fresh(race_id) or _racedb_get_fast(race_id)
    if not d:
        try:
            d = _fast_local_race_detail(race_id)
        except Exception:
            d = None
    if not d:
        if force_hydrate:
            _schedule_fast_card_refresh(race_id, 5)
        return None
    d = _restore_saved_odds(d)
    d = _ensure_race_volatility(d)
    if force_hydrate and (not _bootstrap_analysis_ready(d)):
        _schedule_fast_card_refresh(race_id, 8)
    return _compact_display_snapshot(d)

def _assemble_day_bundle(date: str, allow_network_fill: bool=False) -> dict:
    rows = _bootstrap_rows_local(date)
    details = []
    if rows:
        workers = max(1, min(8, int(os.getenv('DAY_BUNDLE_WORKERS', '6')), len(rows)))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_bootstrap_detail_local, str(r.get('id')), allow_network_fill): str(r.get('id')) for r in rows}
            for fut in as_completed(futures):
                try:
                    d = fut.result()
                except Exception as exc:
                    print('day bundle race failed', futures[fut], exc)
                    d = None
                if d and d.get('id'):
                    details.append(d)
    details.sort(key=lambda d: (str(d.get('circuit') or ''), str(d.get('track') or ''), int(d.get('raceNumber') or 0)))
    display_ids = {str(d.get('id') or '') for d in details if _bootstrap_display_ready(d)}
    analysis_ids = {str(d.get('id') or '') for d in details if _bootstrap_analysis_ready(d)}
    missing = [str(r.get('id') or '') for r in rows if str(r.get('id') or '') not in display_ids]
    source_running = _bootstrap_sources_running(date)
    display_complete = bool(rows) and (not missing) and (not source_running)
    return {'date': date, 'races': rows, 'details': details, 'raceCount': len(rows), 'detailCount': len(display_ids), 'analysisCount': len(analysis_ids), 'missing': missing, 'complete': display_complete, 'displayComplete': display_complete, 'analysisComplete': bool(rows) and len(analysis_ids) >= len(rows), 'sourceRunning': source_running, 'generatedAtEpoch': int(time.time()), 'source': 'nonblocking-day-bundle'}

def _refresh_day_bundle(date: str, force_sources: bool=False, wait_for_complete: bool=False, timeout_sec: float=25.0) -> dict:
    """Single-pass bundle refresh. Missing/outdated races are queued and never block the caller."""
    started = time.time()
    with _site_bootstrap_build_lock:
        with _site_bootstrap_lock:
            _site_bootstrap_state[date] = {'running': True, 'startedAt': int(started), 'raceCount': 0, 'ready': 0, 'missing': []}
        if force_sources or date == _today_iso():
            try:
                _schedule_live_refresh(date, force=bool(force_sources))
            except Exception:
                pass
            try:
                _schedule_central_refresh(date, force=bool(force_sources))
            except Exception:
                pass
        payload = _assemble_day_bundle(date, allow_network_fill=False)
        missing = list(payload.get('missing') or [])
        for rid in missing:
            _schedule_fast_card_refresh(rid, 5)
        for d in payload.get('details') or []:
            if d and d.get('id') and (not _bootstrap_analysis_ready(d)):
                _schedule_fast_card_refresh(str(d.get('id')), 12)
        try:
            DAY_BUNDLES.put(date, payload, bool(payload.get('displayComplete')))
        except Exception:
            pass
        with _site_bootstrap_lock:
            _site_bootstrap_cache[date] = (time.time(), payload)
            _site_bootstrap_state[date] = {'running': False, 'startedAt': int(started), 'finishedAt': int(time.time()), 'raceCount': int(payload.get('raceCount') or 0), 'ready': int(payload.get('detailCount') or 0), 'analysisReady': int(payload.get('analysisCount') or 0), 'missing': missing, 'sourceRunning': bool(payload.get('sourceRunning')), 'elapsedMs': int((time.time() - started) * 1000)}
        return payload

def _schedule_day_bundle_refresh(date: str, force_sources: bool=False) -> None:
    with _site_bootstrap_lock:
        st = _site_bootstrap_state.get(date) or {}
        if st.get('running'):
            return
        _site_bootstrap_state[date] = {'running': True, 'startedAt': int(time.time()), 'raceCount': 0, 'ready': 0, 'missing': []}

    def worker():
        try:
            _refresh_day_bundle(date, force_sources, True, float(os.getenv('DAY_BUNDLE_BUILD_TIMEOUT_SEC', '45')))
        except Exception as exc:
            print('day bundle refresh failed', date, exc)
            with _site_bootstrap_lock:
                st = dict(_site_bootstrap_state.get(date) or {})
                st.update({'running': False, 'error': str(exc), 'finishedAt': int(time.time())})
                _site_bootstrap_state[date] = st
    threading.Thread(target=worker, daemon=True, name='day-bundle-' + date).start()

def _site_bootstrap_payload(date: str, force: bool=False, wait: bool=False) -> dict:
    """
    Customer path is strictly non-blocking.
    Return the best local bundle immediately, then continue full preparation in background.
    v240: a fresh force=1 collector result must not be immediately replaced by an
    older persisted bundle on the next non-force poll.
    """
    stored = DAY_BUNDLES.get(date, complete_only=True)
    recent_force = None
    with _site_bootstrap_lock:
        fc = _site_force_cache.get(date)
        if fc and time.time() - float(fc[0]) <= 60:
            recent_force = dict(fc[1])
    if not force and recent_force and (not stored or _bundle_quality(recent_force) >= _bundle_quality(stored)):
        out = dict(recent_force)
        out['cached'] = False
        out['servedFrom'] = 'recent-force-live'
        return out
    if stored and (not force):
        if date == _today_iso() and int(time.time()) - int(stored.get('updatedAtEpoch') or 0) > 20:
            _schedule_day_bundle_refresh(date, False)
        out = dict(stored)
        out['cached'] = True
        out['servedFrom'] = 'persistent-display-complete'
        return out
    try:
        current = _assemble_day_bundle(date, allow_network_fill=False)
    except Exception as exc:
        print('nonblocking bootstrap assemble failed', date, exc)
        current = {'date': date, 'races': [], 'details': [], 'raceCount': 0, 'detailCount': 0, 'analysisCount': 0, 'missing': [], 'complete': False, 'displayComplete': False, 'analysisComplete': False, 'sourceRunning': False, 'generatedAtEpoch': int(time.time()), 'source': 'nonblocking-day-bundle'}
    if current.get('displayComplete'):
        try:
            DAY_BUNDLES.put(date, current, True)
        except Exception:
            pass
    _schedule_day_bundle_refresh(date, bool(force))
    current['cached'] = False
    current['servedFrom'] = 'local-immediate'
    return current

def _force_day_live_snapshot(date: str, timeout_sec: float=23.0) -> dict:
    """GitHub collector path: all-card live fields first, diagnosis second.

    v304 refreshed each race as one long job (card -> odds -> result -> diagnosis).
    Slow diagnosis jobs could occupy all workers and starve later races before their
    odds call ever started.  v305 splits the phases: every race gets an odds attempt
    first; only then do we spend the remaining budget on results/diagnosis.
    """
    started = time.time()
    try:
        _schedule_live_refresh(date, force=True)
    except Exception:
        pass
    try:
        _schedule_central_refresh(date, force=True)
    except Exception:
        pass
    deadline = started + max(8.0, float(timeout_sec))
    while time.time() < deadline and _bootstrap_sources_running(date):
        if time.time() - started > 2.2:
            break
        time.sleep(0.15)
    rows = _bootstrap_rows_local(date)
    if not rows:
        return _site_bootstrap_payload(date, True, False)

    def snapshot(rid: str) -> dict:
        return _prepared_get_fresh(rid) or _racedb_get_fast(rid) or _fast_local_race_detail(rid) or {}

    def live_coverage(d: dict) -> tuple[int, int, int]:
        hs = [h for h in d.get('horses') or [] if not h.get('scratched') and int(h.get('horseNumber') or 0) > 0]
        got = sum((1 for h in hs if float(h.get('winOdds') or 0) > 0))
        weights = sum((1 for h in hs if int(h.get('bodyWeight') or 0) > 250))
        return (len(hs), got, weights)

    def market_one(row):
        rid = str(row.get('id') or '')
        if not rid:
            return (rid, False)
        try:
            d = snapshot(rid)
            if not _bootstrap_display_ready(d):
                try:
                    _hydrate_fast_card_now(rid, deep_history=False)
                except Exception as exc:
                    print('full-day card hydrate failed', rid, exc)
            body = odds_refresh(rid, 1)
            field = int((body or {}).get('fieldCount') or 0)
            got = int((body or {}).get('oddsCount') or 0)
            return (rid, bool(field and got == field))
        except Exception as exc:
            print('full-day market refresh failed', rid, exc)
            return (rid, False)
    market_workers = max(6, min(int(os.getenv('FULL_DAY_ODDS_WORKERS', '20')), 24, len(rows)))
    market_results = {}
    ex = ThreadPoolExecutor(max_workers=market_workers)
    futures = {ex.submit(market_one, r): str(r.get('id') or '') for r in rows}
    market_deadline = min(deadline - 5.0, time.time() + max(6.0, min(14.0, deadline - time.time() - 5.0)))
    try:
        done, _ = wait(list(futures), timeout=max(0.5, market_deadline - time.time()))
        for fut in done:
            rid = futures[fut]
            try:
                market_results[rid] = bool(fut.result()[1])
            except Exception:
                market_results[rid] = False
    finally:
        ex.shutdown(wait=False, cancel_futures=True)
    missing = []
    for r in rows:
        rid = str(r.get('id') or '')
        field, got, _ = live_coverage(snapshot(rid))
        if rid and field and (got < field):
            missing.append(r)
    if missing and time.time() < deadline - 2.5:
        retry_workers = max(4, min(int(os.getenv('FULL_DAY_ODDS_RETRY_WORKERS', '16')), 20, len(missing)))
        ex = ThreadPoolExecutor(max_workers=retry_workers)
        fs = [ex.submit(market_one, r) for r in missing]
        try:
            wait(fs, timeout=max(0.5, min(4.0, deadline - time.time() - 2.0)))
        finally:
            ex.shutdown(wait=False, cancel_futures=True)
    nowj = _now_jst()
    nowm = nowj.hour * 60 + nowj.minute
    focus = []
    for r in rows:
        st = _race_minutes_server(r)
        remain = st - nowm if st < 9999 else 9999
        if -45 <= remain <= 240 or not _bootstrap_analysis_ready(snapshot(str(r.get('id') or ''))):
            focus.append(r)
    focus.sort(key=lambda r: abs((_race_minutes_server(r) if _race_minutes_server(r) < 9999 else nowm + 9999) - nowm))
    focus = focus[:max(12, min(28, len(focus)))]

    def finish_one(row):
        rid = str(row.get('id') or '')
        if not rid:
            return None
        try:
            st = _race_minutes_server(row)
            if st < 9999 and nowm >= st + 2 and (not _snapshot_final(snapshot(rid))):
                try:
                    _refresh_result_fast(rid)
                except Exception:
                    pass
            try:
                _build_fast_diagnosis_snapshot(rid, allow_network=False, deep_context=False)
            except Exception as exc:
                print('focused diagnosis rebuild failed', rid, exc)
            d = snapshot(rid)
            return _compact_display_snapshot(d) if d else None
        except Exception as exc:
            print('focused live rebuild failed', rid, exc)
            return None
    if focus and time.time() < deadline - 1.2:
        workers = max(4, min(10, len(focus)))
        ex = ThreadPoolExecutor(max_workers=workers)
        fs = [ex.submit(finish_one, r) for r in focus]
        try:
            wait(fs, timeout=max(0.4, deadline - time.time() - 1.0))
        finally:
            ex.shutdown(wait=False, cancel_futures=True)
    out = _assemble_day_bundle(date, allow_network_fill=False)
    if out.get('displayComplete'):
        try:
            DAY_BUNDLES.put(date, out, True)
        except Exception:
            pass
    dc_ready = 0
    for d in out.get('details', []) or []:
        try:
            hh = _data_core_store_health(d, set(), 'force-day')
            if all(((hh.get(k) or {}).get('status') == 'ready' for k in ('card', 'history', 'odds', 'body_weight', 'environment', 'analysis'))):
                dc_ready += 1
        except Exception as exc:
            print('data core force health failed', (d or {}).get('id'), exc)
    out['dataCore'] = {'version': ARVEXQ_DATA_CORE_VERSION, 'readyRaceCount': dc_ready, 'raceCount': len(out.get('races') or [])}
    odds_ready = 0
    odds_partial = 0
    odds_missing = []
    for d in out.get('details', []) or []:
        hs = [h for h in d.get('horses') or [] if not h.get('scratched') and int(h.get('horseNumber') or 0) > 0]
        got = sum((1 for h in hs if float(h.get('winOdds') or 0) > 0))
        if hs and got == len(hs):
            odds_ready += 1
        elif hs and got:
            odds_partial += 1
            odds_missing.append(str(d.get('id') or ''))
        elif hs:
            odds_missing.append(str(d.get('id') or ''))
    out['oddsReadyCount'] = odds_ready
    out['oddsPartialCount'] = odds_partial
    out['oddsMissingRaceIds'] = odds_missing
    out['forceLiveRefresh'] = True
    out['forceElapsedMs'] = int((time.time() - started) * 1000)
    with _site_bootstrap_lock:
        _site_force_cache[date] = (time.time(), dict(out))
        _site_bootstrap_cache[date] = (time.time(), dict(out))
    return out

def _site_bootstrap_warm_loop():
    time.sleep(float(os.getenv('BOOTSTRAP_START_DELAY_SEC', '2.5')))
    while True:
        try:
            _schedule_day_bundle_refresh(_today_iso(), False)
        except Exception as exc:
            print('bundle warmer failed', exc)
        time.sleep(max(20, int(os.getenv('BOOTSTRAP_REFRESH_SEC', '30'))))

def _start_site_bootstrap_warmer():
    enabled = str(os.getenv('ARVEXQ_BOOTSTRAP_WARM', '1')).lower() in {'1', 'true', 'yes', 'on'}
    if enabled:
        threading.Thread(target=_site_bootstrap_warm_loop, daemon=True, name='arvexq-bootstrap').start()

def payout_refresh(race_id: str):
    """Fetch only payouts; do not rebuild history/AI."""
    saved = _prepared_get_fresh(race_id) or _racedb_get_fast(race_id) or _fast_local_race_detail(race_id)
    if not saved:
        raise HTTPException(status_code=404, detail='race not found')
    existing = (saved.get('result') or {}).get('payouts') or []
    if existing:
        return {'raceId': race_id, 'payouts': existing, 'source': (saved.get('result') or {}).get('payoutSource') or '保存済み', 'cached': True}
    payouts = []
    source = ''
    error = ''
    if race_id.startswith('nar-'):
        payouts, src = _fetch_nar_payouts_only(saved)
        source = 'NAR公式' if payouts else ''
        error = '' if payouts else src
        if not payouts:
            try:
                nk = _netkeiba_current_result(saved) or {}
                payouts = nk.get('payouts') or []
                if payouts:
                    source = 'netkeiba結果'
            except Exception as exc:
                error = (error + ' | ' + str(exc)).strip(' |')
    else:
        try:
            result_cname = str(saved.get('resultCname') or '')
            if not result_cname:
                cname = _jra_find_cname(str(saved.get('date') or ''), str(saved.get('track') or ''), int(saved.get('raceNumber') or 0))
                if cname:
                    result_cname = _jra_result_cname_from_card(cname)
            official = _jra_parse_result(result_cname, saved) if result_cname else None
            payouts = ((official or {}).get('result') or {}).get('payouts') or []
            if payouts:
                source = 'JRA公式'
        except Exception as exc:
            error = str(exc)
        if not payouts:
            try:
                nk = _netkeiba_current_result(saved) or {}
                payouts = nk.get('payouts') or []
                if payouts:
                    source = 'netkeiba結果'
            except Exception as exc:
                error = (error + ' | ' + str(exc)).strip(' |')
    if payouts:
        for store_get, store_put in ((lambda: PREPARED_STORE.get(race_id)[0], lambda d: PREPARED_STORE.put(d, force=True)), (lambda: RACEDB.get_race(race_id)[0], lambda d: RACEDB.upsert_race(d))):
            try:
                d = store_get()
                if not d:
                    continue
                res = d.get('result')
                if not isinstance(res, dict):
                    res = {}
                    d['result'] = res
                res['payouts'] = payouts
                res['payoutSource'] = source
                res.pop('payoutError', None)
                store_put(d)
            except Exception as exc:
                print('payout snapshot patch failed', race_id, exc)
    return {'raceId': race_id, 'payouts': payouts, 'source': source, 'cached': False, 'error': error[:240]}

def _merge_live_market_rows(race_id: str, fresh_rows: list[dict], saved: dict | None=None) -> list[dict]:
    """Preserve the best known live fields per horse when a source returns a partial table.

    A live odds page can briefly omit one or more runners while updating.  Never let
    that sparse response erase previously captured odds/body weight for other horses.
    Fresh non-empty fields win; the latest RaceDB point and saved race snapshot fill gaps.
    """
    by_no: dict[int, dict] = {}
    saved = saved or {}
    for h in saved.get('horses') or []:
        try:
            no = int(h.get('horseNumber') or 0)
        except Exception:
            no = 0
        if not no:
            continue
        z = {'horseNumber': no}
        for k in ('winOdds', 'popularity', 'bodyWeight', 'bodyWeightChange', 'oddsForecast', 'referenceBodyWeight', 'referenceBodyWeightDate', 'status', 'scratched', 'oddsSource'):
            if h.get(k) not in (None, ''):
                z[k] = h.get(k)
        by_no[no] = z
    try:
        for h in RACEDB.odds_latest(race_id) or []:
            no = int(h.get('horseNumber') or 0)
            if not no:
                continue
            z = by_no.setdefault(no, {'horseNumber': no})
            for k in ('winOdds', 'popularity', 'oddsSource'):
                if z.get(k) in (None, '') and h.get(k) not in (None, ''):
                    z[k] = h.get(k)
    except Exception as exc:
        print('odds preserve read failed', race_id, exc)
    for h in fresh_rows or []:
        try:
            no = int(h.get('horseNumber') or 0)
        except Exception:
            no = 0
        if not no:
            continue
        z = by_no.setdefault(no, {'horseNumber': no})
        for k, v in h.items():
            if k == 'horseNumber':
                continue
            if v not in (None, ''):
                z[k] = v
    return [by_no[k] for k in sorted(by_no)]

def odds_refresh(race_id: str, force: int=Query(0)):
    saved = _prepared_get_fresh(race_id) or _racedb_get_fast(race_id)
    saved_has_odds = bool(saved and any((h.get('winOdds') not in (None, '') and float(h.get('winOdds') or 0) > 0 for h in saved.get('horses') or [])))
    saved_horses = saved.get('horses') or [] if saved else []
    saved_has_weights = bool(saved_horses and all((h.get('bodyWeight') not in (None, '') for h in saved_horses if not h.get('scratched'))))
    if saved and saved.get('date') != _today_iso() and saved_has_odds:
        return {'raceId': race_id, 'horses': saved_horses, 'oddsSource': saved.get('oddsSource') or '保存済み', 'storedInRaceDB': True, 'oddsUpdatedAt': saved.get('oddsUpdatedAt') or ''}
    if saved and _snapshot_final(saved) and saved_has_odds and saved_has_weights:
        return {'raceId': race_id, 'horses': saved_horses, 'oddsSource': saved.get('oddsSource') or '保存済み', 'storedInRaceDB': True, 'oddsUpdatedAt': saved.get('oddsUpdatedAt') or ''}
    horses = []
    source = ''
    if race_id.startswith('nar-'):
        m = re.match('^nar-(\\d{4}-\\d{2}-\\d{2})-(.+)-(\\d{2})$', race_id)
        if m:
            odds = _nar_live_odds(m.group(2), m.group(1), int(m.group(3)), bool(force))
            merged = {int(no): dict(z or {}) for no, z in odds.items()}
            if not merged or any((not (z or {}).get('bodyWeight') for z in merged.values())):
                try:
                    detail = dict(saved or {})
                    detail.update({'id': race_id, 'date': m.group(1), 'track': m.group(2), 'raceNumber': int(m.group(3))})
                    if not detail.get('horses'):
                        try:
                            qd = _fast_local_race_detail(race_id)
                            if qd:
                                detail = qd
                        except Exception:
                            pass
                    for h in _nar_official_card_rows_fast(detail):
                        no = int(h.get('horseNumber') or 0)
                        if not no:
                            continue
                        z = merged.setdefault(no, {})
                        for k in ('bodyWeight', 'bodyWeightChange', 'status', 'scratched'):
                            if z.get(k) in (None, '') and h.get(k) not in (None, ''):
                                z[k] = h.get(k)
                    if merged and (not odds):
                        source = 'NAR公式出馬表'
                except Exception as exc:
                    print('NAR official body weight fallback failed', race_id, exc)
            try:
                detail = dict(saved or {})
                detail.update({'id': race_id, 'date': m.group(1), 'track': m.group(2), 'raceNumber': int(m.group(3))})
                nk = _nar_netkeiba_preview_rows(detail, bool(force)) or {}
                for no, z0 in nk.items():
                    z = merged.setdefault(int(no), {})
                    official_live = bool(z.get('winOdds') and (not z.get('oddsForecast')))
                    if not official_live and z0.get('winOdds'):
                        z['winOdds'] = z0.get('winOdds')
                        z['popularity'] = z0.get('popularity')
                        z['oddsSource'] = z0.get('oddsSource')
                        z['oddsForecast'] = bool(z0.get('oddsForecast'))
                    for k in ('bodyWeight', 'bodyWeightChange'):
                        if z.get(k) in (None, '') and z0.get(k) not in (None, ''):
                            z[k] = z0.get(k)
                if nk and (not odds):
                    source = 'netkeiba予想オッズ'
            except Exception as exc:
                print('NAR netkeiba preview fallback failed', race_id, exc)
            if saved:
                saved_by = {int(h.get('horseNumber') or 0): h for h in saved.get('horses') or []}
                for no, h0 in saved_by.items():
                    z = merged.setdefault(no, {})
                    if not z.get('bodyWeight'):
                        rw, rd = _reference_weight_from_horse(h0)
                        if rw:
                            z['referenceBodyWeight'] = rw
                            z['referenceBodyWeightDate'] = rd
            if saved and _snapshot_final(saved):
                for f in (saved.get('result') or {}).get('finishers') or []:
                    no = int(f.get('horseNumber') or 0)
                    if not no:
                        continue
                    z = merged.setdefault(no, {})
                    for k in ('bodyWeight', 'bodyWeightChange', 'popularity', 'winOdds'):
                        if z.get(k) in (None, '') and f.get(k) not in (None, ''):
                            z[k] = f.get(k)
            for no, z in sorted(merged.items()):
                horses.append({'horseNumber': int(no), **{k: v for k, v in z.items() if v is not None}})
            if not source:
                source = 'NAR公式' if odds else next((str(z.get('oddsSource') or '') for z in merged.values() if z.get('oddsSource')), '') or ('NAR公式出馬表' if horses else '')
    else:
        mm = re.match('^jra-(20\\d{2}-\\d{2}-\\d{2})-([^\\-]+)-(\\d{2})$', race_id)
        detail = {}
        if mm:
            detail = _jra_program_lookup(mm.group(1), mm.group(2), int(mm.group(3))) or {'date': mm.group(1), 'track': mm.group(2), 'raceNumber': int(mm.group(3))}
            detail['netkeibaRaceId'] = detail.get('netkeibaRaceId') or _netkeiba_program_race_id(mm.group(1), mm.group(2), int(mm.group(3)))
            merged = {}
            try:
                cname = _jra_find_cname(mm.group(1), mm.group(2), int(mm.group(3)))
                if cname:
                    jr = _jra_parse_race(cname, supplement_profiles=False) or {}
                    for h in jr.get('horses', []) or []:
                        no = int(h.get('horseNumber') or 0)
                        if not no:
                            continue
                        z = merged.setdefault(no, {})
                        for k in ('winOdds', 'popularity', 'bodyWeight', 'bodyWeightChange', 'status', 'scratched'):
                            if h.get(k) not in (None, ''):
                                z[k] = h.get(k)
                    if any((float(h.get('winOdds') or 0) > 0 or h.get('bodyWeight') for h in jr.get('horses') or [])):
                        source = 'JRA公式'
            except Exception as exc:
                print('fast odds JRA failed', race_id, exc)
            try:
                nk = _netkeiba_live_win_odds(detail, bool(force)) or {}
                for no, z0 in nk.items():
                    z = merged.setdefault(int(no), {})
                    for k in ('winOdds', 'popularity', 'bodyWeight', 'bodyWeightChange', 'status', 'scratched'):
                        if z.get(k) in (None, '') and (z0 or {}).get(k) not in (None, ''):
                            z[k] = (z0 or {}).get(k)
            except Exception as exc:
                print('fast odds secondary fallback failed', race_id, exc)
            if not any((float((z or {}).get('winOdds') or 0) > 0 for z in merged.values())):
                try:
                    card_detail = dict(detail)
                    card_detail['id'] = race_id
                    for h in _netkeiba_card_rows_fast(card_detail):
                        no = int(h.get('horseNumber') or 0)
                        if not no:
                            continue
                        z = merged.setdefault(no, {})
                        for k in ('winOdds', 'popularity', 'bodyWeight', 'bodyWeightChange', 'status', 'scratched'):
                            if h.get(k) not in (None, ''):
                                z[k] = h.get(k)
                    if any((float((z or {}).get('winOdds') or 0) > 0 for z in merged.values())):
                        source = 'netkeiba出馬表'
                except Exception as exc:
                    print('fast odds card scrape failed', race_id, exc)
            if not any((float((z or {}).get('winOdds') or 0) > 0 for z in merged.values())):
                try:
                    result_detail = saved or detail or {}
                    nkres = _netkeiba_current_result(result_detail) or {}
                    for f in nkres.get('finishers', []) or []:
                        no = int(f.get('horseNumber') or 0)
                        if not no:
                            continue
                        z = merged.setdefault(no, {})
                        for k in ('winOdds', 'popularity', 'bodyWeight', 'bodyWeightChange'):
                            if f.get(k) not in (None, ''):
                                z[k] = f.get(k)
                    if any((float((z or {}).get('winOdds') or 0) > 0 for z in merged.values())):
                        source = 'netkeiba最終'
                except Exception as exc:
                    print('final odds result fallback failed', race_id, exc)
            for no, z in sorted(merged.items()):
                horses.append({'horseNumber': no, **z})
            if not source and horses:
                source = 'netkeiba'
    horses = _merge_live_market_rows(race_id, horses, saved)
    if not source:
        source = next((str(h.get('oddsSource') or '') for h in horses if h.get('oddsSource')), '')
    if horses:
        try:
            RACEDB.save_odds(race_id, horses, source)
        except Exception as exc:
            print('RaceDB odds save failed', race_id, exc)
        try:
            snapshot, _ = PREPARED_STORE.get(race_id)
            if snapshot:
                by_no = {int(h.get('horseNumber') or 0): h for h in horses}
                for h in snapshot.get('horses', []):
                    update = by_no.get(int(h.get('horseNumber') or 0), {})
                    for key in ('winOdds', 'popularity', 'bodyWeight', 'bodyWeightChange', 'oddsForecast', 'referenceBodyWeight', 'referenceBodyWeightDate', 'status', 'scratched'):
                        if update.get(key) is not None:
                            h[key] = update[key]
                    if update.get('oddsSource'):
                        h['oddsSource'] = update.get('oddsSource')
                snapshot['oddsSource'] = source
                snapshot['oddsUpdatedAt'] = _now_jst().strftime('%H:%M:%S')
                PREPARED_STORE.put(snapshot, force=True)
                try:
                    RACEDB.upsert_race(snapshot)
                except Exception:
                    pass
        except Exception as exc:
            print('odds snapshot update failed', exc)
        try:
            with _site_bootstrap_lock:
                _site_bootstrap_cache.pop(_today_iso(), None)
        except Exception:
            pass
    if not horses:
        try:
            stored = RACEDB.odds_latest(race_id) or []
            if stored:
                horses = stored
                source = next((str(x.get('oddsSource') or '') for x in stored if x.get('oddsSource')), '保存済み')
        except Exception:
            pass
    live = [h for h in horses if not h.get('scratched') and int(h.get('horseNumber') or 0) > 0]
    odds_count = sum((1 for h in live if float(h.get('winOdds') or 0) > 0))
    return {'raceId': race_id, 'horses': horses, 'oddsSource': source, 'oddsUpdatedAt': _now_jst().strftime('%H:%M:%S'), 'storedInRaceDB': bool(horses), 'fieldCount': len(live), 'oddsCount': odds_count, 'oddsComplete': bool(live) and odds_count == len(live)}

def _auto_odds_targets() -> list[dict]:
    date = _today_iso()
    rows = []
    try:
        rows.extend(nar_race_summaries(date))
    except Exception:
        pass
    try:
        rows.extend(central_race_summaries(date, allow_network=False))
    except Exception:
        pass
    nowj = _now_jst()
    nowm = nowj.hour * 60 + nowj.minute
    out = []
    for r in rows:
        if not r.get('id') or _snapshot_final(r):
            continue
        start = _race_minutes_server(r)
        if start >= 9999:
            out.append(r)
            continue
        remain = start - nowm
        if remain < -8:
            continue
        out.append(r)
    out.sort(key=lambda r: _race_minutes_server(r))
    return out

def _auto_odds_cycle():
    global _auto_odds_state
    with _auto_odds_lock:
        if _auto_odds_state.get('running'):
            return
        _auto_odds_state.update({'running': True, 'lastStart': int(time.time()), 'checked': 0, 'updated': 0, 'error': ''})
    checked = updated = 0
    errors = []
    try:
        now = time.time()
        targets = []
        nowj = _now_jst()
        nowm = nowj.hour * 60 + nowj.minute
        for r in _auto_odds_targets():
            rid = str(r.get('id') or '')
            start = _race_minutes_server(r)
            remain = start - nowm if start < 9999 else 9999
            cadence = 30 if remain <= 30 else 60 if remain <= 180 else 180
            last = float(_auto_odds_last.get(rid, 0))
            if now - last < cadence:
                continue
            _auto_odds_last[rid] = now
            targets.append(r)

        def one(r):
            rid = str(r.get('id') or '')
            try:
                last_body = None
                for attempt in range(2):
                    last_body = odds_refresh(rid, 1)
                    hs = (last_body or {}).get('horses') or []
                    live = [h for h in hs if not h.get('scratched') and int(h.get('horseNumber') or 0) > 0]
                    got = sum((1 for h in live if float(h.get('winOdds') or 0) > 0))
                    weights = sum((1 for h in live if int(h.get('bodyWeight') or 0) > 250))
                    if live and got == len(live):
                        return (rid, {'complete': True, 'odds': got, 'field': len(live), 'weights': weights})
                    if attempt == 0:
                        time.sleep(0.15)
                return (rid, {'complete': False, 'odds': got if 'got' in locals() else 0, 'field': len(live) if 'live' in locals() else 0, 'weights': weights if 'weights' in locals() else 0})
            except Exception as exc:
                return (rid, exc)
        workers = max(1, min(20, int(os.getenv('AUTO_ODDS_WORKERS', '18')), len(targets))) if targets else 0
        if workers:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                for rid, res in pool.map(one, targets):
                    checked += 1
                    if isinstance(res, dict) and res.get('complete'):
                        updated += 1
                    elif isinstance(res, dict):
                        _auto_odds_last[rid] = min(float(_auto_odds_last.get(rid, 0)), time.time() - 20)
                    elif isinstance(res, Exception):
                        errors.append(rid + ': ' + str(res))
    finally:
        with _auto_odds_lock:
            _auto_odds_state.update({'running': False, 'lastFinish': int(time.time()), 'checked': checked, 'updated': updated, 'error': ' | '.join(errors[-5:])})

def _auto_odds_loop():
    time.sleep(float(os.getenv('AUTO_ODDS_START_DELAY_SEC', '0.7')))
    while True:
        try:
            _auto_odds_cycle()
        except Exception as exc:
            print('auto odds cycle failed', exc)
        time.sleep(max(8, int(os.getenv('AUTO_ODDS_LOOP_SEC', '10'))))

def _start_auto_odds_collector():
    enabled = str(os.getenv('ARVEXQ_AUTO_ODDS', '1')).lower() in {'1', 'true', 'yes', 'on'}
    if enabled:
        threading.Thread(target=_auto_odds_loop, daemon=True, name='arvexq-auto-odds').start()

def _racedb_live_cycle() -> None:
    today = _today_iso()
    rows = []
    _schedule_live_refresh(today, False)
    _schedule_central_refresh(today, False)
    try:
        rows.extend(nar_race_summaries(today))
    except Exception as exc:
        print('RaceDB NAR list failed', exc)
    try:
        rows.extend(central_race_summaries(today, allow_network=True, force=False))
    except Exception as exc:
        print('RaceDB JRA list failed', exc)
    if rows:
        _schedule_prewarm(rows, today, '')
    if not bool(int(os.getenv('RACEDB_AUTO_ODDS', '1'))):
        return
    nowm = _now_jst().hour * 60 + _now_jst().minute
    window = int(os.getenv('RACEDB_ODDS_WINDOW_MIN', '90'))
    limit = max(1, int(os.getenv('RACEDB_ODDS_MAX_RACES', '4')))
    upcoming = []
    for r in rows:
        if r.get('result'):
            continue
        t = str(r.get('startTime') or '')
        m = re.match('^(\\d{1,2}):(\\d{2})', t)
        if not m:
            continue
        rm = int(m.group(1)) * 60 + int(m.group(2))
        delta = rm - nowm
        if -5 <= delta <= window:
            upcoming.append((delta, r))
    upcoming.sort(key=lambda x: x[0])
    for _, r in upcoming[:limit]:
        try:
            odds_refresh(str(r.get('id') or ''))
        except Exception as exc:
            print('RaceDB automatic odds failed', r.get('id'), exc)

def _start_racedb_daemon() -> None:
    global _racedb_daemon_started
    if str(os.getenv('ARVEXQ_COMMERCIAL_COLLECTOR', '1')).lower() in {'1', 'true', 'yes', 'on'}:
        return
    if not bool(int(os.getenv('RACEDB_AUTO_UPDATE', '1'))):
        return
    with _racedb_daemon_lock:
        if _racedb_daemon_started:
            return
        _racedb_daemon_started = True

    def worker():
        time.sleep(float(os.getenv('RACEDB_START_DELAY_SEC', '2')))
        while True:
            try:
                _racedb_live_cycle()
            except Exception as exc:
                print('RaceDB live cycle failed', exc)
            time.sleep(max(30, int(os.getenv('RACEDB_UPDATE_SEC', '120'))))
    threading.Thread(target=worker, daemon=True, name='RaceDB-live-updater').start()
