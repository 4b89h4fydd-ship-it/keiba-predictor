class NarArchiveParser:
    def parse(self, zip_bytes: bytes) -> tuple[list[RaceRow], list[EntryRow]]:
        race_rows = strip_header(read_csv_from_zip(zip_bytes, "_racelist.csv"))
        horse_rows = strip_header(read_csv_from_zip(zip_bytes, "_horselist.csv"))

        races: list[RaceRow] = []
        for row in race_rows:
            if len(row) < 33:
                continue
            corner_orders: list[dict[int, int]] = []
            for i in range(8):
                idx = RACE_IDX["corner_order_start"] + i
                if idx < len(row) and _clean(row[idx]):
                    corner_orders.append(parse_corner_order(row[idx]))
            races.append(
                RaceRow(
                    track=_clean(row[RACE_IDX["track"]]),
                    date=_iso_date(row[RACE_IDX["date"]]),
                    race_no=_int(row[RACE_IDX["race_no"]]),
                    start_time=_start_time(row[RACE_IDX["start_time"]]),
                    title=_clean(row[RACE_IDX["title"]]),
                    distance=_int(row[RACE_IDX["distance"]]),
                    weather=_normalize_weather(row[RACE_IDX["weather"]]),
                    condition=_normalize_condition(row[RACE_IDX["condition"]]),
                    field_size=_int(row[RACE_IDX["field_size"]]),
                    prize=tuple(_int(row[RACE_IDX[f"prize{i}"]]) for i in range(1, 6)),
                    corners=corner_orders,
                )
            )

        entries: list[EntryRow] = []
        for row in horse_rows:
            if len(row) < 19:
                continue
            entries.append(
                EntryRow(
                    track=_clean(row[HORSE_IDX["track"]]),
                    date=_iso_date(row[HORSE_IDX["date"]]),
                    race_no=_int(row[HORSE_IDX["race_no"]]),
                    frame_no=_int(row[HORSE_IDX["frame_no"]]),
                    horse_no=_int(row[HORSE_IDX["horse_no"]]),
                    name=_clean(row[HORSE_IDX["name"]]),
                    sex=_normalize_sex(row[HORSE_IDX["sex"]]),
                    age=_int(row[HORSE_IDX["age"]]),
                    jockey=_clean(row[HORSE_IDX["jockey"]]),
                    carried_weight=_carried_weight(row[HORSE_IDX["carried_weight"]]),
                    trainer=_clean(row[HORSE_IDX["trainer"]]),
                    finish=_int(row[HORSE_IDX["finish"]]) if len(row) > HORSE_IDX["finish"] else 0,
                    time_seconds=_time_seconds(row[HORSE_IDX["time"]]) if len(row) > HORSE_IDX["time"] else 0,
                )
            )
        return races, entries


class NarStore:
    def __init__(self, path: Path = DB_PATH):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self._migrate()

    def _migrate(self) -> None:
        self.conn.executescript(
            """
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS races (
                track TEXT NOT NULL,
                date TEXT NOT NULL,
                race_no INTEGER NOT NULL,
                start_time TEXT NOT NULL DEFAULT '',
                scheduled_start_time TEXT NOT NULL DEFAULT '',
                title TEXT NOT NULL DEFAULT '',
                distance INTEGER NOT NULL DEFAULT 0,
                weather TEXT NOT NULL DEFAULT '不明',
                condition TEXT NOT NULL DEFAULT '不明',
                field_size INTEGER NOT NULL DEFAULT 0,
                prize1 INTEGER NOT NULL DEFAULT 0,
                prize2 INTEGER NOT NULL DEFAULT 0,
                prize3 INTEGER NOT NULL DEFAULT 0,
                prize4 INTEGER NOT NULL DEFAULT 0,
                prize5 INTEGER NOT NULL DEFAULT 0,
                corners_json TEXT NOT NULL DEFAULT '[]',
                PRIMARY KEY(track, date, race_no)
            );
            CREATE TABLE IF NOT EXISTS entries (
                track TEXT NOT NULL,
                date TEXT NOT NULL,
                race_no INTEGER NOT NULL,
                frame_no INTEGER NOT NULL DEFAULT 0,
                horse_no INTEGER NOT NULL,
                name TEXT NOT NULL,
                sex TEXT NOT NULL DEFAULT '牡',
                age INTEGER NOT NULL DEFAULT 0,
                carried_weight REAL NOT NULL DEFAULT 0,
                jockey TEXT NOT NULL DEFAULT '',
                trainer TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT '',
                finish INTEGER NOT NULL DEFAULT 0,
                time_seconds REAL NOT NULL DEFAULT 0,
                corner_positions_json TEXT NOT NULL DEFAULT '[]',
                PRIMARY KEY(track, date, race_no, horse_no)
            );
            CREATE INDEX IF NOT EXISTS idx_entries_name_date ON entries(name, date);
            CREATE INDEX IF NOT EXISTS idx_entries_jockey_date ON entries(jockey, date);
            CREATE INDEX IF NOT EXISTS idx_entries_trainer_date ON entries(trainer, date);
            CREATE TABLE IF NOT EXISTS sync_log (
                cache_key TEXT PRIMARY KEY,
                synced_at INTEGER NOT NULL,
                archive_path TEXT NOT NULL DEFAULT ''
            );
            """
        )
        race_cols = {row[1] for row in self.conn.execute("PRAGMA table_info(races)").fetchall()}
        if "scheduled_start_time" not in race_cols:
            self.conn.execute("ALTER TABLE races ADD COLUMN scheduled_start_time TEXT NOT NULL DEFAULT ''")
        entry_cols = {row[1] for row in self.conn.execute("PRAGMA table_info(entries)").fetchall()}
        if "status" not in entry_cols:
            self.conn.execute("ALTER TABLE entries ADD COLUMN status TEXT NOT NULL DEFAULT ''")
        self.conn.execute("UPDATE races SET scheduled_start_time=start_time WHERE scheduled_start_time=''")
        self.conn.commit()

    def import_rows(self, races: Iterable[RaceRow], entries: Iterable[EntryRow]) -> None:
        races = list(races)
        race_lookup = {(r.track, r.date, r.race_no): r for r in races}
        with self.conn:
            for r in races:
                self.conn.execute(
                    """
                    INSERT INTO races(track,date,race_no,start_time,scheduled_start_time,title,distance,weather,condition,field_size,
                                      prize1,prize2,prize3,prize4,prize5,corners_json)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(track,date,race_no) DO UPDATE SET
                      start_time=excluded.start_time,title=excluded.title,distance=excluded.distance,
                      weather=CASE WHEN excluded.weather NOT IN ('','不明') THEN excluded.weather ELSE races.weather END,
                      condition=CASE WHEN excluded.condition NOT IN ('','不明') THEN excluded.condition ELSE races.condition END,
                      field_size=excluded.field_size,
                      prize1=excluded.prize1,prize2=excluded.prize2,prize3=excluded.prize3,
                      prize4=excluded.prize4,prize5=excluded.prize5,corners_json=excluded.corners_json
                    """,
                    (
                        r.track, r.date, r.race_no, r.start_time, r.start_time, r.title, r.distance, r.weather, r.condition,
                        r.field_size, *r.prize,
                        json.dumps([{str(k): v for k, v in c.items()} for c in r.corners], ensure_ascii=False),
                    ),
                )
            for e in entries:
                race = race_lookup.get((e.track, e.date, e.race_no))
                corners: list[int] = []
                if race:
                    for c in race.corners:
                        if e.horse_no in c:
                            corners.append(c[e.horse_no])
                self.conn.execute(
                    """
                    INSERT INTO entries(track,date,race_no,frame_no,horse_no,name,sex,age,carried_weight,
                                        jockey,trainer,status,finish,time_seconds,corner_positions_json)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(track,date,race_no,horse_no) DO UPDATE SET
                      frame_no=excluded.frame_no,name=excluded.name,sex=excluded.sex,age=excluded.age,
                      carried_weight=excluded.carried_weight,jockey=excluded.jockey,trainer=excluded.trainer,
                      status=CASE WHEN entries.status<>'' THEN entries.status ELSE excluded.status END,
                      finish=excluded.finish,time_seconds=excluded.time_seconds,
                      corner_positions_json=excluded.corner_positions_json
                    """,
                    (
                        e.track, e.date, e.race_no, e.frame_no, e.horse_no, e.name, e.sex, e.age,
                        e.carried_weight, e.jockey, e.trainer, "", e.finish, e.time_seconds,
                        json.dumps(corners, ensure_ascii=False),
                    ),
                )

    def mark_synced(self, cache_key: str, archive_path: Path) -> None:
        with self.conn:
            self.conn.execute(
                "INSERT OR REPLACE INTO sync_log(cache_key,synced_at,archive_path) VALUES(?,?,?)",
                (cache_key, int(time.time()), str(archive_path)),
            )

    def synced_at(self, cache_key: str) -> int | None:
        row = self.conn.execute("SELECT synced_at FROM sync_log WHERE cache_key=?", (cache_key,)).fetchone()
        return int(row[0]) if row else None

    def stats(self, role: str, name: str, cutoff: str) -> dict[str, int]:
        if role not in {"jockey", "trainer"} or not name:
            return {"starts": 0, "wins": 0, "seconds": 0, "thirds": 0}
        row = self.conn.execute(
            f"""
            SELECT COUNT(*) starts,
                   SUM(CASE WHEN finish=1 THEN 1 ELSE 0 END) wins,
                   SUM(CASE WHEN finish=2 THEN 1 ELSE 0 END) seconds,
                   SUM(CASE WHEN finish=3 THEN 1 ELSE 0 END) thirds
            FROM entries WHERE {role}=? AND date<? AND finish>0
            """,
            (name, cutoff),
        ).fetchone()
        return {k: int(row[k] or 0) for k in ("starts", "wins", "seconds", "thirds")}

    def role_profile(self, role: str, name: str, cutoff: str, track: str, distance: int, condition: str) -> dict:
        """Condition-aware jockey/trainer record available strictly before the target race."""
        if role not in {"jockey", "trainer"} or not name:
            return {"overall": 0.5, "track": 0.5, "distance": 0.5, "condition": 0.5,
                    "leaderRate": 0.0, "early3Rate": 0.0, "starts": 0}
        rows = self.conn.execute(
            f"""
            SELECT e.finish, e.corner_positions_json, r.track, r.distance, r.condition
            FROM entries e
            JOIN races r ON r.track=e.track AND r.date=e.date AND r.race_no=e.race_no
            WHERE e.{role}=? AND e.date<? AND e.finish>0
            ORDER BY e.date DESC, e.race_no DESC
            LIMIT 400
            """,
            (name, cutoff),
        ).fetchall()

        def rate(subset):
            if not subset:
                return 0.5
            top3 = sum(1 for x in subset if 0 < int(x["finish"] or 0) <= 3)
            return top3 / len(subset)

        track_rows = [x for x in rows if (x["track"] or "") == track]
        dist_rows = [x for x in rows if abs(int(x["distance"] or 0) - int(distance or 0)) <= 200]
        cond_rows = [x for x in rows if condition and condition != "不明" and (x["condition"] or "") == condition]
        lead = early3 = valid = 0
        for x in rows[:120]:
            try:
                pos = json.loads(x["corner_positions_json"] or "[]")
            except Exception:
                pos = []
            if not pos:
                continue
            first = _int(str(pos[0]))
            if first <= 0:
                continue
            valid += 1
            if first == 1:
                lead += 1
            if first <= 3:
                early3 += 1
        return {
            "overall": rate(rows),
            "track": rate(track_rows),
            "distance": rate(dist_rows),
            "condition": rate(cond_rows),
            "leaderRate": (lead / valid) if valid else 0.0,
            "early3Rate": (early3 / valid) if valid else 0.0,
            "starts": len(rows),
        }

    def prize_before(self, horse_name: str, cutoff: str) -> int:
        row = self.conn.execute(
            """
            SELECT COALESCE(SUM(CASE e.finish
                WHEN 1 THEN r.prize1 WHEN 2 THEN r.prize2 WHEN 3 THEN r.prize3
                WHEN 4 THEN r.prize4 WHEN 5 THEN r.prize5 ELSE 0 END), 0) AS prize
            FROM entries e
            JOIN races r ON r.track=e.track AND r.date=e.date AND r.race_no=e.race_no
WHERE e.name=? AND e.date<? AND e.finish>0
            """,
            (horse_name, cutoff),
        ).fetchone()
        return int(row["prize"] or 0)

    def recent_races(self, horse_name: str, cutoff: str, limit: int = 5) -> list[dict]:
        rows = self.conn.execute(
            """
            SELECT e.*, r.title, r.distance, r.weather, r.condition, r.field_size, r.prize1
            FROM entries e
            JOIN races r ON r.track=e.track AND r.date=e.date AND r.race_no=e.race_no
            WHERE e.name=? AND e.date<? AND e.finish>0
            ORDER BY e.date DESC, e.race_no DESC
            LIMIT ?
            """,
            (horse_name, cutoff, limit),
        ).fetchall()
        return [
            {
                "date": row["date"],
                "track": row["track"],
                "raceNumber": int(row["race_no"] or 0),
                "raceId": f"nar-{row['date']}-{row['track']}-{int(row['race_no'] or 0):02d}",
                "title": row["title"] or f"{int(row['race_no'] or 0)}R",
                "distance": int(row["distance"] or 0),
                "condition": row["condition"] or "不明",
                "weather": row["weather"] or "不明",
                "finish": int(row["finish"] or 0),
                "timeSeconds": float(row["time_seconds"] or 0),
                "cornerPositions": json.loads(row["corner_positions_json"] or "[]"),
                "fieldSize": int(row["field_size"] or 0),
                "racePrize1": int(row["prize1"] or 0),
                "carriedWeight": float(row["carried_weight"] or 0),
                "jockey": row["jockey"] or "",
                "trainer": row["trainer"] or "",
            }
            for row in rows
        ]

    def races_json(self, iso_date: str) -> list[dict]:
        race_rows = self.conn.execute(
            "SELECT * FROM races WHERE date=? ORDER BY track, race_no", (iso_date,)
        ).fetchall()
        result: list[dict] = []
        for race in race_rows:
            entries = self.conn.execute(
                "SELECT * FROM entries WHERE track=? AND date=? AND race_no=? ORDER BY horse_no",
                (race["track"], iso_date, race["race_no"]),
            ).fetchall()
            if not entries:
                continue
            horses = []
            for e in entries:
                horses.append(
                    {
                        "id": _stable_id(iso_date, race["track"], race["race_no"], e["horse_no"], e["name"]),
                        "horseNumber": int(e["horse_no"]),
                        "frameNumber": int(e["frame_no"] or 0),
                        "name": e["name"],
                        "age": int(e["age"] or 0),
                        "sex": e["sex"] or "牡",
                        "carriedWeight": float(e["carried_weight"] or 0),
                        "jockey": e["jockey"] or "",
                        "trainer": e["trainer"] or "",
                        "jockeyStats": self.stats("jockey", e["jockey"], iso_date),
                        "trainerStats": self.stats("trainer", e["trainer"], iso_date),
                        "jockeyProfile": self.role_profile("jockey", e["jockey"], iso_date, race["track"], int(race["distance"] or 0), race["condition"] or "不明"),
                        "trainerProfile": self.role_profile("trainer", e["trainer"], iso_date, race["track"], int(race["distance"] or 0), race["condition"] or "不明"),
                        "prizeMoneyAtRace": self.prize_before(e["name"], iso_date),
                        "recentRaces": self.recent_races(e["name"], iso_date, 5),
                    }
                )
            finishers = []
            for e in entries:
                fin = int(e["finish"] or 0)
                if fin > 0:
                    finishers.append({
                        "finish": fin,
                        "horseNumber": int(e["horse_no"]),
                        "frameNumber": int(e["frame_no"] or 0),
                        "name": e["name"],
                        "timeSeconds": float(e["time_seconds"] or 0),
                        "cornerPositions": json.loads(e["corner_positions_json"] or "[]"),
                    })
            finishers.sort(key=lambda x: (x["finish"], x["horseNumber"]))
            need = min(3, len(entries))
            ranks = {x["finish"] for x in finishers}
            finalized = need > 0 and all(i in ranks for i in range(1, need + 1))
            result_obj = {"status": "確定", "finishers": finishers} if finalized else None
            result.append(
                {
                    "id": f"nar-{iso_date}-{race['track']}-{int(race['race_no']):02d}",
                    "circuit": "地方",
                    "date": iso_date,
                    "track": race["track"],
                    "raceNumber": int(race["race_no"]),
                    "title": race["title"] or f"{int(race['race_no'])}R",
                    "distance": int(race["distance"] or 0),
                    "condition": race["condition"] or "不明",
                    "weather": race["weather"] or "不明",
                    "fieldSize": int(race["field_size"] or len(entries)),
                    "racePrize1": int(race["prize1"] or 0),
                    "surface": "",
                    "startTime": race["start_time"] or "",
                    "scheduledStartTime": race["scheduled_start_time"] or race["start_time"] or "",
                    "startTimeChanged": bool((race["scheduled_start_time"] or "") and (race["start_time"] or "") and race["scheduled_start_time"] != race["start_time"]),
                    "horses": horses,
                    "result": result_obj,
                    "source": "NAR公式",
                }
            )
        return result

    def coverage(self) -> dict:
        row = self.conn.execute("SELECT MIN(date) min_date, MAX(date) max_date FROM races").fetchone()
        return {"minDate": row["min_date"], "maxDate": row["max_date"]}


class NarSync:
    def __init__(self, store: NarStore | None = None, parser: NarArchiveParser | None = None):
        self.store = store or NarStore()
        self.parser = parser or NarArchiveParser()
        ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)

    def _download(self, url: str, destination: Path) -> bytes:
        request = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 Version/18.0 Mobile/15E148 Safari/604.1",
                "Accept": "application/zip,application/octet-stream,*/*",
                "Referer": "https://www.keiba.go.jp/KeibaWeb/TodayRaceInfo/TodayRaceInfoTop",
                "Accept-Language": "ja-JP,ja;q=0.9",
            },
        )
        with urllib.request.urlopen(request, timeout=45) as response:
            data = response.read()
        if not zipfile.is_zipfile(io.BytesIO(data)):
            raise RuntimeError("NAR response was not a ZIP archive")
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        return data

    def import_zip_bytes(self, data: bytes, cache_key: str, archive_path: Path) -> dict:
        races, entries = self.parser.parse(data)
        self.store.import_rows(races, entries)
        self.store.mark_synced(cache_key, archive_path)
        return {"races": len(races), "entries": len(entries), "cacheKey": cache_key}

    def sync_daily(self, force: bool = False) -> dict:
        cache_key = "daily"
        synced = self.store.synced_at(cache_key)
        ttl = int(os.getenv("NAR_DAILY_TTL_SECONDS", "120"))
        if not force and synced and int(time.time()) - synced < ttl:
            return {"status": "cached", "cacheKey": cache_key}
        dest = ARCHIVE_DIR / "daily_race.zip"
        data = self._download(NAR_DAILY_RACE_URL, dest)
        info = self.import_zip_bytes(data, cache_key, dest)
        return {"status": "synced", **info}

    def sync_month(self, year: int, month: int, force: bool = False) -> dict:
        if not 1 <= month <= 12:
            raise ValueError("month must be 1...12")
        cache_key = f"month-{year:04d}-{month:02d}"
        synced = self.store.synced_at(cache_key)
        today = datetime.now().date()
        is_current_month = (year == today.year and month == today.month)
        current_ttl = int(os.getenv("NAR_CURRENT_MONTH_TTL_SECONDS", "300"))
        if not force and synced:
            age = int(time.time()) - synced
            if (not is_current_month) or age < current_ttl:
                return {"status": "cached", "cacheKey": cache_key}
        dest = ARCHIVE_DIR / f"{year:04d}{month:02d}_race.zip"
        url = NAR_MONTHLY_RACE_URL.format(year=year, month=month)
        data = self._download(url, dest)
        info = self.import_zip_bytes(data, cache_key, dest)
        return {"status": "synced", **info}

    def import_file(self, path: Path, cache_key: str | None = None) -> dict:
        data = path.read_bytes()
        key = cache_key or f"file-{path.name}-{int(path.stat().st_mtime)}"
        return self.import_zip_bytes(data, key, path)



CENTRAL_DB_PATH = DATA_ROOT / "central" / "central.sqlite3"

class CentralStore:
    def __init__(self, path: Path = CENTRAL_DB_PATH):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS central_races(
              id TEXT PRIMARY KEY,
              date TEXT NOT NULL,
              track TEXT NOT NULL,
              race_no INTEGER NOT NULL,
              payload TEXT NOT NULL,
              updated_at INTEGER NOT NULL
            )
        """)
        self.conn.execute("CREATE INDEX IF NOT EXISTS idx_central_date ON central_races(date,track,race_no)")
        self.conn.commit()

    def upsert(self, rows: list[dict]) -> int:
        n = 0
        with self.conn:
            for raw in rows:
                incoming = normalize_central_race(raw)
                if not incoming:
                    continue
                old_row=self.conn.execute("SELECT payload FROM central_races WHERE id=?",(incoming["id"],)).fetchone()
                if old_row:
                    try:old=json.loads(old_row["payload"])
                    except Exception:old={}
                    merged=dict(old) if isinstance(old,dict) else {}
                    # Lightweight schedule rows must never erase a prepared card/result.
                    for k,v in incoming.items():
                        if k=="horses":
                            if isinstance(v,list) and v:merged[k]=v
                            continue
                        if k=="result":
                            if isinstance(v,dict) and v:merged[k]=v
                            continue
                        if k in {"weather","condition"}:
                            if v not in (None,"","不明"):merged[k]=v
                            elif k not in merged:merged[k]="不明"
                            continue
                        if k=="fieldSize":
                            if int(v or 0)>0:merged[k]=int(v)
                            continue
                        if v not in (None,"",0,[]):
                            merged[k]=v
                        elif k not in merged:
                            merged[k]=v
                    r=normalize_central_race(merged) or incoming
                else:
                    r=incoming
                self.conn.execute(
                    """INSERT INTO central_races(id,date,track,race_no,payload,updated_at)
                       VALUES(?,?,?,?,?,?)
                       ON CONFLICT(id) DO UPDATE SET date=excluded.date,track=excluded.track,
                         race_no=excluded.race_no,payload=excluded.payload,updated_at=excluded.updated_at""",
                    (r["id"], r["date"], r["track"], r["raceNumber"], json.dumps(r, ensure_ascii=False), int(time.time())),
                )
                n += 1
        return n

    def races_json(self, iso_date: str) -> list[dict]:
        rows = self.conn.execute("SELECT payload FROM central_races WHERE date=? ORDER BY track,race_no", (iso_date,)).fetchall()
        return [json.loads(x["payload"]) for x in rows]

    def coverage(self) -> dict:
        row = self.conn.execute("SELECT MIN(date) min_date, MAX(date) max_date, COUNT(*) cnt FROM central_races").fetchone()
        return {"minDate": row["min_date"], "maxDate": row["max_date"], "count": int(row["cnt"] or 0)}

from arvexq.prediction.mass_prerace_bridge import prepare_mass_prerace_fields, apply_mass_prerace_fields, frozen_mass_fields
from arvexq.selection.race_selectability_snapshot import prepare_race_selectability_fields, apply_race_selectability_fields, frozen_selectability_fields
class PreparedRaceStore:
    def __init__(self, path: Path = PREPARED_DB_PATH):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.path, timeout=3)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS prepared_races (
                    race_id TEXT PRIMARY KEY,
                    race_date TEXT NOT NULL DEFAULT '',
                    circuit TEXT NOT NULL DEFAULT '',
                    updated_at INTEGER NOT NULL,
                    payload TEXT NOT NULL
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_prepared_date ON prepared_races(race_date, circuit)")
            conn.execute("CREATE TABLE IF NOT EXISTS horse_snapshots(race_id TEXT,horse_no INTEGER,payload TEXT NOT NULL,PRIMARY KEY(race_id,horse_no))")
            conn.execute("CREATE VIEW IF NOT EXISTS race_snapshot AS SELECT * FROM prepared_races")
            conn.execute("CREATE VIEW IF NOT EXISTS horse_snapshot AS SELECT * FROM horse_snapshots")
            conn.commit()
        finally:
            conn.close()

    def get(self, race_id: str) -> tuple[dict | None, int]:
        conn = sqlite3.connect(self.path, timeout=2)
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute("SELECT updated_at,payload FROM prepared_races WHERE race_id=?", (race_id,)).fetchone()
            if not row:
                return None, 0
            try:
                return json.loads(row["payload"]), int(row["updated_at"] or 0)
            except Exception:
                return None, 0
        finally:
            conn.close()

    def put(self, detail: dict, force: bool = False) -> None:
        race_id = str(detail.get("id") or "")
        if not race_id:
            return
        if not _racedb_snapshot_usable(detail):
            return
        mass_fields=prepare_mass_prerace_fields(detail)
        selectability_fields=prepare_race_selectability_fields(detail)
        now = int(time.time())
        detail.setdefault("preparedMeta", {})
        revision_data={k:v for k,v in detail.items() if k!="preparedMeta"}
        detail["preparedMeta"]["revision"]=hashlib.sha256(json.dumps(revision_data,sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()[:24]
        detail["preparedMeta"].update({
            "build": "v87",
            "prepared": True,
            "preparedAtEpoch": now,
            "metricsPrecomputed": True,
        })
        clean=_compact_display_snapshot(_strip_excluded(detail))
        detail.clear();detail.update(clean)
        if mass_fields:apply_mass_prerace_fields(detail,mass_fields)
        if selectability_fields:apply_race_selectability_fields(detail,selectability_fields)
        payload = json.dumps(detail, ensure_ascii=False, separators=(",", ":"))
        conn = sqlite3.connect(self.path, timeout=3)
        try:
            conn.execute("BEGIN IMMEDIATE")
            old=conn.execute("SELECT payload FROM prepared_races WHERE race_id=?",(race_id,)).fetchone()
            if old:
                previous=json.loads(old[0])
                if isinstance(previous.get("preRacePrediction"),dict) and (_arvexq_sealed_lock(previous) or _prediction_clock_state(detail)[0]=="started" or not isinstance(detail.get("preRacePrediction"),dict)):
                    detail["preRacePrediction"]=previous["preRacePrediction"]
                    previous_mass=frozen_mass_fields(previous)
                    if previous_mass:apply_mass_prerace_fields(detail,previous_mass)
                    previous_selectability=frozen_selectability_fields(previous)
                    if previous_selectability:apply_race_selectability_fields(detail,previous_selectability)
                    audit=_prediction_audit_from_lock(detail)
                    if audit:detail["predictionAudit"]=audit
                    payload=json.dumps(detail,ensure_ascii=False,separators=(",",":"))
                prev_meta=previous.get("preparedMeta") or {}
                prev_payouts=((previous.get("result") or {}).get("payouts") or [])
                new_payouts=((detail.get("result") or {}).get("payouts") or [])
                frozen=_snapshot_final(previous) or str(previous.get("date") or "")<_today_iso()
                can_upgrade=bool(force or prev_meta.get("fastPartial") or (not prev_payouts and new_payouts))
                if _racedb_snapshot_usable(previous) and frozen and not can_upgrade:
                    detail.clear();detail.update(previous)
                    return
            conn.execute(
                """
                INSERT INTO prepared_races(race_id,race_date,circuit,updated_at,payload)
                VALUES(?,?,?,?,?)
                ON CONFLICT(race_id) DO UPDATE SET
                    race_date=excluded.race_date,
                    circuit=excluded.circuit,
                    updated_at=excluded.updated_at,
                    payload=excluded.payload
                """,
                (race_id, str(detail.get("date") or ""), str(detail.get("circuit") or ""), now, payload),
            )
            conn.execute("DELETE FROM horse_snapshots WHERE race_id=?",(race_id,))
            conn.executemany("INSERT OR REPLACE INTO horse_snapshots(race_id,horse_no,payload) VALUES(?,?,?)",[(race_id,int(h.get("horseNumber") or 0),json.dumps(h,ensure_ascii=False)) for h in detail.get("horses",[])])
            conn.commit()
        finally:
            conn.close()

    def delete(self, race_id: str) -> None:
        conn = sqlite3.connect(self.path, timeout=2)
        try:
            conn.execute("DELETE FROM prepared_races WHERE race_id=?", (race_id,))
            conn.commit()
        finally:
            conn.close()

    def status(self, race_date: str = "", circuit: str = "") -> dict:
        conn = sqlite3.connect(self.path, timeout=2)
        conn.row_factory = sqlite3.Row
        try:
            where=[]; args=[]
            if race_date:
                where.append("race_date=?"); args.append(race_date)
            if circuit:
                where.append("circuit=?"); args.append(circuit)
            sql="SELECT COUNT(*) cnt, MAX(updated_at) last FROM prepared_races"
            if where: sql += " WHERE " + " AND ".join(where)
            row=conn.execute(sql,args).fetchone()
            return {"count":int(row["cnt"] or 0),"last":int(row["last"] or 0)}
        finally:
            conn.close()


# --- v86 RaceDB ---------------------------------------------------------
# Normalized local data bank.  The UI can return a saved race immediately while
# official/public sources refresh in the background.  RACEDB_PATH can point at a
# persistent disk.  With the default /tmp path it still works as a fast cache but
# will be rebuilt after an ephemeral host restart.
class RaceDataBank:
    def __init__(self, path: Path = RACEDB_PATH):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.path, timeout=5)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS race_snapshots (
                    race_id TEXT PRIMARY KEY,
                    race_date TEXT NOT NULL DEFAULT '',
                    circuit TEXT NOT NULL DEFAULT '',
                    track TEXT NOT NULL DEFAULT '',
                    race_no INTEGER NOT NULL DEFAULT 0,
                    title TEXT NOT NULL DEFAULT '',
                    surface TEXT NOT NULL DEFAULT '',
                    distance INTEGER NOT NULL DEFAULT 0,
                    condition TEXT NOT NULL DEFAULT '',
                    weather TEXT NOT NULL DEFAULT '',
                    start_time TEXT NOT NULL DEFAULT '',
                    updated_at INTEGER NOT NULL,
                    payload TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_racedb_races_date ON race_snapshots(race_date,circuit,track,race_no);

                CREATE TABLE IF NOT EXISTS horse_master (
                    horse_key TEXT PRIMARY KEY,
                    name TEXT NOT NULL DEFAULT '',
                    horse_external_id TEXT NOT NULL DEFAULT '',
                    sex TEXT NOT NULL DEFAULT '',
                    age INTEGER NOT NULL DEFAULT 0,
                    birthday TEXT NOT NULL DEFAULT '',
                    sire TEXT NOT NULL DEFAULT '',
                    dam TEXT NOT NULL DEFAULT '',
                    damsire TEXT NOT NULL DEFAULT '',
                    trainer TEXT NOT NULL DEFAULT '',
                    owner TEXT NOT NULL DEFAULT '',
                    producer TEXT NOT NULL DEFAULT '',
                    updated_at INTEGER NOT NULL,
                    raw_json TEXT NOT NULL DEFAULT '{}'
                );
                CREATE INDEX IF NOT EXISTS idx_racedb_horse_name ON horse_master(name);

                CREATE TABLE IF NOT EXISTS horse_entries (
                    race_id TEXT NOT NULL,
                    horse_no INTEGER NOT NULL,
                    horse_key TEXT NOT NULL DEFAULT '',
                    frame_no INTEGER NOT NULL DEFAULT 0,
                    name TEXT NOT NULL DEFAULT '',
                    jockey TEXT NOT NULL DEFAULT '',
                    trainer TEXT NOT NULL DEFAULT '',
                    carried_weight REAL,
                    body_weight INTEGER,
                    body_weight_change INTEGER,
                    prize_money INTEGER NOT NULL DEFAULT 0,
                    ten1f TEXT,
                    ten TEXT,
                    agari TEXT,
                    estimated_popularity TEXT,
                    pedigree_json TEXT NOT NULL DEFAULT '{}',
                    style_json TEXT NOT NULL DEFAULT '{}',
                    fit_json TEXT NOT NULL DEFAULT '{}',
                    debut_json TEXT NOT NULL DEFAULT '{}',
                    jump_json TEXT NOT NULL DEFAULT '{}',
                    representative_json TEXT NOT NULL DEFAULT '{}',
                    opponent_level REAL,
                    metrics_json TEXT NOT NULL DEFAULT '{}',
                    sources_json TEXT NOT NULL DEFAULT '[]',
                    updated_at INTEGER NOT NULL,
                    raw_json TEXT NOT NULL DEFAULT '{}',
                    PRIMARY KEY(race_id,horse_no)
                );
                CREATE INDEX IF NOT EXISTS idx_racedb_entries_horse ON horse_entries(horse_key);

                CREATE TABLE IF NOT EXISTS past_runs (
                    horse_key TEXT NOT NULL,
                    run_key TEXT NOT NULL,
                    race_date TEXT NOT NULL DEFAULT '',
                    track TEXT NOT NULL DEFAULT '',
                    title TEXT NOT NULL DEFAULT '',
                    distance INTEGER NOT NULL DEFAULT 0,
                    surface TEXT NOT NULL DEFAULT '',
                    condition TEXT NOT NULL DEFAULT '',
                    weather TEXT NOT NULL DEFAULT '',
                    finish INTEGER NOT NULL DEFAULT 0,
                    time_seconds REAL,
                    agari3f REAL,
                    agari_rank INTEGER,
                    frame_no INTEGER NOT NULL DEFAULT 0,
                    horse_no INTEGER NOT NULL DEFAULT 0,
                    carried_weight REAL,
                    jockey TEXT NOT NULL DEFAULT '',
                    corner_json TEXT NOT NULL DEFAULT '[]',
                    opponent_level REAL,
                    representative INTEGER NOT NULL DEFAULT 0,
                    source TEXT NOT NULL DEFAULT '',
                    updated_at INTEGER NOT NULL,
                    raw_json TEXT NOT NULL DEFAULT '{}',
                    PRIMARY KEY(horse_key,run_key)
                );
                CREATE INDEX IF NOT EXISTS idx_racedb_runs_date ON past_runs(horse_key,race_date DESC);
                CREATE INDEX IF NOT EXISTS idx_racedb_runs_cutoff ON past_runs(race_date,jockey);
                CREATE INDEX IF NOT EXISTS idx_racedb_runs_jockey ON past_runs(jockey,race_date);
                CREATE INDEX IF NOT EXISTS idx_racedb_horse_sire ON horse_master(sire);
                CREATE INDEX IF NOT EXISTS idx_racedb_runs_track_date ON past_runs(track,race_date);

                CREATE TABLE IF NOT EXISTS odds_history (
                    race_id TEXT NOT NULL,
                    horse_no INTEGER NOT NULL,
                    captured_at INTEGER NOT NULL,
                    win_odds REAL,
                    popularity INTEGER,
                    source TEXT NOT NULL DEFAULT '',
                    raw_json TEXT NOT NULL DEFAULT '{}',
                    PRIMARY KEY(race_id,horse_no,captured_at)
                );
                CREATE INDEX IF NOT EXISTS idx_racedb_odds_race ON odds_history(race_id,captured_at DESC);

                CREATE TABLE IF NOT EXISTS race_analysis (
                    race_id TEXT PRIMARY KEY,
                    updated_at INTEGER NOT NULL,
                    scenario_json TEXT NOT NULL DEFAULT '{}',
                    horse_diagnosis_json TEXT NOT NULL DEFAULT '[]',
                    raw_json TEXT NOT NULL DEFAULT '{}'
                );

                CREATE TABLE IF NOT EXISTS source_state (
                    source_key TEXT PRIMARY KEY,
                    updated_at INTEGER NOT NULL,
                    status TEXT NOT NULL DEFAULT '',
                    note TEXT NOT NULL DEFAULT ''
                );

                CREATE TABLE IF NOT EXISTS field_state (
                    race_id TEXT NOT NULL,
                    field_key TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'missing',
                    completeness INTEGER NOT NULL DEFAULT 0,
                    source TEXT NOT NULL DEFAULT '',
                    updated_at INTEGER NOT NULL DEFAULT 0,
                    last_attempt_at INTEGER NOT NULL DEFAULT 0,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    note TEXT NOT NULL DEFAULT '',
                    value_hash TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY(race_id,field_key)
                );
                CREATE INDEX IF NOT EXISTS idx_racedb_field_status ON field_state(status,updated_at);
                CREATE INDEX IF NOT EXISTS idx_racedb_field_race ON field_state(race_id,field_key);

                CREATE TABLE IF NOT EXISTS collector_runs (
                    run_id TEXT PRIMARY KEY,
                    race_id TEXT NOT NULL,
                    started_at INTEGER NOT NULL,
                    finished_at INTEGER NOT NULL DEFAULT 0,
                    status TEXT NOT NULL DEFAULT '',
                    attempted_fields TEXT NOT NULL DEFAULT '[]',
                    before_json TEXT NOT NULL DEFAULT '{}',
                    after_json TEXT NOT NULL DEFAULT '{}',
                    note TEXT NOT NULL DEFAULT ''
                );
                CREATE INDEX IF NOT EXISTS idx_racedb_collector_race ON collector_runs(race_id,started_at DESC);
                """
            )
            # v86 forward-compatible migration for an existing RaceDB.
            # CR/share from v85 are intentionally no longer read or written.
            def ensure_column(table: str, column: str, ddl: str) -> None:
                cols={str(r[1]) for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
                if column not in cols:
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")
            for col,ddl in (
                ("style_json","TEXT NOT NULL DEFAULT '{}'"),("fit_json","TEXT NOT NULL DEFAULT '{}'"),
                ("debut_json","TEXT NOT NULL DEFAULT '{}'"),("jump_json","TEXT NOT NULL DEFAULT '{}'"),
                ("representative_json","TEXT NOT NULL DEFAULT '{}'"),("opponent_level","REAL")
            ): ensure_column("horse_entries",col,ddl)
            for col,ddl in (
                ("agari3f","REAL"),("agari_rank","INTEGER"),("frame_no","INTEGER NOT NULL DEFAULT 0"),
                ("horse_no","INTEGER NOT NULL DEFAULT 0"),("opponent_level","REAL"),("representative","INTEGER NOT NULL DEFAULT 0")
            ): ensure_column("past_runs",col,ddl)
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def _horse_key(h: dict) -> str:
        ext=str(h.get("_jraHorseCname") or h.get("_netkeibaHorseId") or h.get("horseId") or "").strip()
        if ext:return "id:"+ext
        name=str(h.get("name") or "").strip()
        return "name:"+name if name else ""

    @staticmethod
    def _run_key(rr: dict) -> str:
        base="|".join(str(rr.get(k) or "") for k in ("raceId","date","track","title","distance","finish","timeSeconds"))
        return hashlib.sha1(base.encode("utf-8","ignore")).hexdigest()

    def upsert_race(self, detail: dict) -> None:
        if not isinstance(detail,dict):return
        race_id=str(detail.get("id") or "").strip()
        if not race_id:return
        now=int(time.time())
        detail=_strip_excluded(detail)
        conn=sqlite3.connect(self.path,timeout=5)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            old=conn.execute("SELECT payload FROM race_snapshots WHERE race_id=?",(race_id,)).fetchone()
            if old:
                try:previous=json.loads(old[0])
                except Exception:previous={}
                if isinstance(previous.get("preRacePrediction"),dict) and (_arvexq_sealed_lock(previous) or _prediction_clock_state(detail)[0]=="started" or not isinstance(detail.get("preRacePrediction"),dict)):
                    detail["preRacePrediction"]=previous["preRacePrediction"]
            snapshot_payload=_compact_display_snapshot(detail)
            payload=json.dumps(snapshot_payload,ensure_ascii=False,separators=(",",":"),default=str)
            conn.execute(
                """INSERT INTO race_snapshots(race_id,race_date,circuit,track,race_no,title,surface,distance,condition,weather,start_time,updated_at,payload)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(race_id) DO UPDATE SET race_date=excluded.race_date,circuit=excluded.circuit,track=excluded.track,
                   race_no=excluded.race_no,title=excluded.title,surface=excluded.surface,distance=excluded.distance,condition=excluded.condition,
                   weather=excluded.weather,start_time=excluded.start_time,updated_at=excluded.updated_at,payload=excluded.payload""",
                (race_id,str(detail.get("date") or ""),str(detail.get("circuit") or ""),str(detail.get("track") or ""),int(detail.get("raceNumber") or 0),
                 str(detail.get("title") or ""),str(detail.get("surface") or ""),int(detail.get("distance") or 0),str(detail.get("condition") or ""),
                 str(detail.get("weather") or ""),str(detail.get("startTime") or ""),now,payload)
            )
            for h in detail.get("horses",[]) or []:
                if not isinstance(h,dict):continue
                no=int(h.get("horseNumber") or 0)
                if no<=0:continue
                hk=self._horse_key(h)
                ped=h.get("pedigree") if isinstance(h.get("pedigree"),dict) else {}
                smart=h.get("smartRc") if isinstance(h.get("smartRc"),dict) else {}
                ext=str(h.get("_jraHorseCname") or h.get("_netkeibaHorseId") or h.get("horseId") or "")
                conn.execute(
                    """INSERT INTO horse_master(horse_key,name,horse_external_id,sex,age,birthday,sire,dam,damsire,trainer,owner,producer,updated_at,raw_json)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                       ON CONFLICT(horse_key) DO UPDATE SET name=excluded.name,horse_external_id=CASE WHEN excluded.horse_external_id<>'' THEN excluded.horse_external_id ELSE horse_master.horse_external_id END,
                       sex=CASE WHEN excluded.sex<>'' THEN excluded.sex ELSE horse_master.sex END,age=CASE WHEN excluded.age>0 THEN excluded.age ELSE horse_master.age END,
                       birthday=CASE WHEN excluded.birthday<>'' THEN excluded.birthday ELSE horse_master.birthday END,sire=CASE WHEN excluded.sire<>'' THEN excluded.sire ELSE horse_master.sire END,
                       dam=CASE WHEN excluded.dam<>'' THEN excluded.dam ELSE horse_master.dam END,damsire=CASE WHEN excluded.damsire<>'' THEN excluded.damsire ELSE horse_master.damsire END,
                       trainer=CASE WHEN excluded.trainer<>'' THEN excluded.trainer ELSE horse_master.trainer END,owner=CASE WHEN excluded.owner<>'' THEN excluded.owner ELSE horse_master.owner END,
                       producer=CASE WHEN excluded.producer<>'' THEN excluded.producer ELSE horse_master.producer END,updated_at=excluded.updated_at,raw_json=excluded.raw_json""",
                    (hk,str(h.get("name") or ""),ext,str(h.get("sex") or ""),int(h.get("age") or 0),str(h.get("birthday") or ""),
                     str(ped.get("sire") or ""),str(ped.get("dam") or ""),str(ped.get("damsire") or ped.get("damSire") or ""),str(h.get("trainer") or ""),
                     str(h.get("owner") or ""),str(h.get("producer") or ""),now,json.dumps(h,ensure_ascii=False,separators=(",",":"),default=str))
                )
                conn.execute(
                    """INSERT INTO horse_entries(race_id,horse_no,horse_key,frame_no,name,jockey,trainer,carried_weight,body_weight,body_weight_change,prize_money,
                       ten1f,ten,agari,estimated_popularity,pedigree_json,style_json,fit_json,debut_json,jump_json,representative_json,opponent_level,metrics_json,sources_json,updated_at,raw_json)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                       ON CONFLICT(race_id,horse_no) DO UPDATE SET horse_key=excluded.horse_key,frame_no=excluded.frame_no,name=excluded.name,jockey=excluded.jockey,
                       trainer=excluded.trainer,carried_weight=excluded.carried_weight,body_weight=excluded.body_weight,body_weight_change=excluded.body_weight_change,
                       prize_money=excluded.prize_money,ten1f=COALESCE(excluded.ten1f,horse_entries.ten1f),ten=COALESCE(excluded.ten,horse_entries.ten),
                       agari=COALESCE(excluded.agari,horse_entries.agari),estimated_popularity=COALESCE(excluded.estimated_popularity,horse_entries.estimated_popularity),
                       pedigree_json=excluded.pedigree_json,style_json=excluded.style_json,fit_json=excluded.fit_json,debut_json=excluded.debut_json,
                       jump_json=excluded.jump_json,representative_json=excluded.representative_json,opponent_level=excluded.opponent_level,
                       metrics_json=excluded.metrics_json,sources_json=excluded.sources_json,updated_at=excluded.updated_at,raw_json=excluded.raw_json""",
                    (race_id,no,hk,int(h.get("frameNumber") or 0),str(h.get("name") or ""),str(h.get("jockey") or ""),str(h.get("trainer") or ""),
                     h.get("carriedWeight"),h.get("bodyWeight"),h.get("bodyWeightChange"),int(h.get("prizeMoneyAtRace") or 0),
                     None if smart.get("ten1f") in (None,"") else str(smart.get("ten1f")),None if smart.get("ten") in (None,"") else str(smart.get("ten")),
                     None if smart.get("agari") in (None,"") else str(smart.get("agari")),None if smart.get("estimatedPopularity") in (None,"") else str(smart.get("estimatedPopularity")),
                     json.dumps(ped,ensure_ascii=False,separators=(",",":"),default=str),
                     json.dumps((h.get("precomputedMetrics") or {}).get("style") or {},ensure_ascii=False,separators=(",",":"),default=str),
                     json.dumps((h.get("precomputedMetrics") or {}).get("fit") or {},ensure_ascii=False,separators=(",",":"),default=str),
                     json.dumps({"isDebut":bool(h.get("debutNoHistory")),"analysisMode":detail.get("analysisMode")},ensure_ascii=False,separators=(",",":")),
                     json.dumps(h.get("jumpStats") or h.get("obstacleStats") or {},ensure_ascii=False,separators=(",",":"),default=str),
                     json.dumps(h.get("representativeRun") or {},ensure_ascii=False,separators=(",",":"),default=str),
                     (h.get("precomputedMetrics") or {}).get("fit",{}).get("level"),
                     json.dumps(h.get("precomputedMetrics") or {},ensure_ascii=False,separators=(",",":"),default=str),
                     json.dumps(detail.get("dataSources") or [],ensure_ascii=False,separators=(",",":"),default=str),now,json.dumps(h,ensure_ascii=False,separators=(",",":"),default=str))
                )
                for rr in (h.get("allPastRuns") or h.get("recentRaces") or []):
                    if not isinstance(rr,dict):continue
                    rk=self._run_key(rr)
                    conn.execute(
                        """INSERT INTO past_runs(horse_key,run_key,race_date,track,title,distance,surface,condition,weather,finish,time_seconds,agari3f,agari_rank,frame_no,horse_no,carried_weight,jockey,corner_json,opponent_level,representative,source,updated_at,raw_json)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                           ON CONFLICT(horse_key,run_key) DO UPDATE SET updated_at=excluded.updated_at,raw_json=excluded.raw_json,
                           agari3f=COALESCE(excluded.agari3f,past_runs.agari3f),agari_rank=COALESCE(excluded.agari_rank,past_runs.agari_rank),
                           opponent_level=COALESCE(excluded.opponent_level,past_runs.opponent_level),representative=MAX(past_runs.representative,excluded.representative)""",
                        (hk,rk,str(rr.get("date") or ""),str(rr.get("track") or ""),str(rr.get("title") or ""),int(rr.get("distance") or 0),str(rr.get("surface") or ""),
                         str(rr.get("condition") or ""),str(rr.get("weather") or ""),int(rr.get("finish") or 0),rr.get("timeSeconds"),rr.get("agari3f") or rr.get("agari"),
                         rr.get("agariRank") or rr.get("agari_rank"),int(rr.get("frameNumber") or 0),int(rr.get("horseNumber") or 0),rr.get("carriedWeight"),str(rr.get("jockey") or ""),
                         json.dumps(rr.get("cornerPositions") or [],ensure_ascii=False,separators=(",",":")),rr.get("opponentLevel"),1 if rr.get("representative") else 0,
                         str(rr.get("source") or ""),now,json.dumps(rr,ensure_ascii=False,separators=(",",":"),default=str))
                    )
            conn.commit()
        finally:
            conn.close()

    def get_race(self, race_id: str) -> tuple[dict | None,int]:
        conn=sqlite3.connect(self.path,timeout=2);conn.row_factory=sqlite3.Row
        try:
            row=conn.execute("SELECT updated_at,payload FROM race_snapshots WHERE race_id=?",(race_id,)).fetchone()
            if not row:return None,0
            try:return json.loads(row["payload"]),int(row["updated_at"] or 0)
            except Exception:return None,0
        finally:conn.close()

    def upsert_past_runs(self, horse: dict, runs: list[dict]) -> int:
        if not isinstance(horse,dict) or not runs:return 0
        hk=self._horse_key(horse)
        if not hk:return 0
        now=int(time.time());count=0
        conn=sqlite3.connect(self.path,timeout=5)
        try:
            for rr in runs:
                if not isinstance(rr,dict):continue
                rr=_strip_excluded(rr)
                rk=self._run_key(rr)
                conn.execute(
                    """INSERT INTO past_runs(horse_key,run_key,race_date,track,title,distance,surface,condition,weather,finish,time_seconds,agari3f,agari_rank,frame_no,horse_no,carried_weight,jockey,corner_json,opponent_level,representative,source,updated_at,raw_json)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                       ON CONFLICT(horse_key,run_key) DO UPDATE SET updated_at=excluded.updated_at,raw_json=excluded.raw_json,
                       agari3f=COALESCE(excluded.agari3f,past_runs.agari3f),agari_rank=COALESCE(excluded.agari_rank,past_runs.agari_rank),
                       opponent_level=COALESCE(excluded.opponent_level,past_runs.opponent_level),representative=MAX(past_runs.representative,excluded.representative)""",
                    (hk,rk,str(rr.get("date") or ""),str(rr.get("track") or ""),str(rr.get("title") or ""),int(rr.get("distance") or 0),str(rr.get("surface") or ""),
                     str(rr.get("condition") or ""),str(rr.get("weather") or ""),int(rr.get("finish") or 0),rr.get("timeSeconds"),rr.get("agari3f") or rr.get("agari"),
                     rr.get("agariRank") or rr.get("agari_rank"),int(rr.get("frameNumber") or 0),int(rr.get("horseNumber") or 0),rr.get("carriedWeight"),str(rr.get("jockey") or ""),
                     json.dumps(rr.get("cornerPositions") or [],ensure_ascii=False,separators=(",",":")),rr.get("opponentLevel"),1 if rr.get("representative") else 0,
                     str(rr.get("source") or ""),now,json.dumps(rr,ensure_ascii=False,separators=(",",":"),default=str)))
                count+=1
            conn.commit();return count
        finally:conn.close()

    def source_updated(self, source_key: str) -> int:
        conn=sqlite3.connect(self.path,timeout=2);conn.row_factory=sqlite3.Row
        try:
            row=conn.execute("SELECT updated_at FROM source_state WHERE source_key=?",(source_key,)).fetchone()
            return int(row["updated_at"] or 0) if row else 0
        finally:conn.close()

    def mark_source(self, source_key: str, status: str = "done", note: str = "") -> None:
        conn=sqlite3.connect(self.path,timeout=2)
        try:
            conn.execute("INSERT INTO source_state(source_key,updated_at,status,note) VALUES(?,?,?,?) ON CONFLICT(source_key) DO UPDATE SET updated_at=excluded.updated_at,status=excluded.status,note=excluded.note",
                         (source_key,int(time.time()),status,note[:500]))
            conn.commit()
        finally:conn.close()

    def save_odds(self, race_id: str, rows: list[dict], source: str = "", captured_at: int | None = None) -> int:
        if not rows:return 0
        # Round to 15 seconds so a polling burst cannot create pointless duplicates.
        ts=int(captured_at or time.time());ts=ts-(ts%15)
        conn=sqlite3.connect(self.path,timeout=3);count=0
        try:
            for z in rows:
                z=_strip_excluded(z)
                try:no=int(z.get("horseNumber") or 0)
                except Exception:no=0
                if no<=0:continue
                try:wo=float(z.get("winOdds")) if z.get("winOdds") not in (None,"") else None
                except Exception:wo=None
                try:pop=int(z.get("popularity")) if z.get("popularity") not in (None,"") else None
                except Exception:pop=None
                conn.execute("INSERT OR REPLACE INTO odds_history(race_id,horse_no,captured_at,win_odds,popularity,source,raw_json) VALUES(?,?,?,?,?,?,?)",
                             (race_id,no,ts,wo,pop,str(source or z.get("oddsSource") or ""),json.dumps(z,ensure_ascii=False,separators=(",",":"),default=str)))
                count+=1
            conn.commit();return count
        finally:conn.close()

    def odds_latest(self, race_id: str) -> list[dict]:
        conn=sqlite3.connect(self.path,timeout=2);conn.row_factory=sqlite3.Row
        try:
            rows=conn.execute("""SELECT o.* FROM odds_history o JOIN (SELECT horse_no,MAX(captured_at) t FROM odds_history WHERE race_id=? GROUP BY horse_no) x
                                 ON o.horse_no=x.horse_no AND o.captured_at=x.t WHERE o.race_id=? ORDER BY o.horse_no""",(race_id,race_id)).fetchall()
            return [{"horseNumber":int(r["horse_no"]),"winOdds":r["win_odds"],"popularity":r["popularity"],"oddsSource":r["source"],"capturedAt":int(r["captured_at"])} for r in rows]
        finally:conn.close()

    def save_analysis(self, race_id: str, payload: dict) -> None:
        if not race_id or not isinstance(payload,dict):return
        payload=_strip_excluded(payload)
        scenarios=payload.get("scenarios") or {}
        horses=payload.get("horses") or []
        now=int(time.time())
        conn=sqlite3.connect(self.path,timeout=3)
        try:
            conn.execute("INSERT INTO race_analysis(race_id,updated_at,scenario_json,horse_diagnosis_json,raw_json) VALUES(?,?,?,?,?) ON CONFLICT(race_id) DO UPDATE SET updated_at=excluded.updated_at,scenario_json=excluded.scenario_json,horse_diagnosis_json=excluded.horse_diagnosis_json,raw_json=excluded.raw_json",
                         (race_id,now,json.dumps(scenarios,ensure_ascii=False,separators=(",",":"),default=str),json.dumps(horses,ensure_ascii=False,separators=(",",":"),default=str),json.dumps(payload,ensure_ascii=False,separators=(",",":"),default=str)))
            conn.commit()
        finally:conn.close()

    def get_analysis(self, race_id: str) -> dict | None:
        conn=sqlite3.connect(self.path,timeout=2);conn.row_factory=sqlite3.Row
        try:
            row=conn.execute("SELECT raw_json FROM race_analysis WHERE race_id=?",(race_id,)).fetchone()
            return json.loads(row["raw_json"]) if row else None
        except Exception:return None
        finally:conn.close()

    def status(self, race_date: str = "", circuit: str = "") -> dict:
        conn=sqlite3.connect(self.path,timeout=2);conn.row_factory=sqlite3.Row
        try:
            where=[];args=[]
            if race_date:where.append("race_date=?");args.append(race_date)
            if circuit:where.append("circuit=?");args.append(circuit)
            sql="SELECT COUNT(*) cnt,MAX(updated_at) last FROM race_snapshots"+(" WHERE "+" AND ".join(where) if where else "")
            rr=conn.execute(sql,args).fetchone();hm=conn.execute("SELECT COUNT(*) c FROM horse_master").fetchone();pr=conn.execute("SELECT COUNT(*) c FROM past_runs").fetchone();od=conn.execute("SELECT COUNT(*) c FROM odds_history").fetchone();an=conn.execute("SELECT COUNT(*) c FROM race_analysis").fetchone()
            return {"races":int(rr["cnt"] or 0),"last":int(rr["last"] or 0),"horses":int(hm["c"] or 0),"pastRuns":int(pr["c"] or 0),"oddsPoints":int(od["c"] or 0),"analyses":int(an["c"] or 0),"path":str(self.path)}
        finally:conn.close()

class DayBundleStore:
    def __init__(self,path:Path):
        self.path=path
        self.path.parent.mkdir(parents=True,exist_ok=True)
        conn=sqlite3.connect(self.path,timeout=5)
        try:
            conn.execute("""CREATE TABLE IF NOT EXISTS day_bundles(
                race_date TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                complete INTEGER NOT NULL DEFAULT 0,
                race_count INTEGER NOT NULL DEFAULT 0,
                detail_count INTEGER NOT NULL DEFAULT 0,
                updated_at INTEGER NOT NULL
            )""")
            conn.commit()
        finally:conn.close()

    def get(self,race_date:str,complete_only:bool=False)->dict|None:
        conn=sqlite3.connect(self.path,timeout=3);conn.row_factory=sqlite3.Row
        try:
            sql="SELECT * FROM day_bundles WHERE race_date=?"
            args=[race_date]
            if complete_only:sql+=" AND complete=1"
            row=conn.execute(sql,args).fetchone()
            if not row:return None
            try:p=json.loads(row["payload"])
            except Exception:return None
            p["persisted"]=True
            p["updatedAtEpoch"]=int(row["updated_at"] or 0)
            p["complete"]=bool(row["complete"])
            p["raceCount"]=int(row["race_count"] or 0)
            p["detailCount"]=int(row["detail_count"] or 0)
            return p
        finally:conn.close()

    def put(self,race_date:str,payload:dict,complete:bool)->None:
        if not race_date or not isinstance(payload,dict):return
        conn=sqlite3.connect(self.path,timeout=5)
        try:
            conn.execute("""INSERT INTO day_bundles(race_date,payload,complete,race_count,detail_count,updated_at)
                            VALUES(?,?,?,?,?,?)
                            ON CONFLICT(race_date) DO UPDATE SET
                              payload=excluded.payload,complete=excluded.complete,
                              race_count=excluded.race_count,detail_count=excluded.detail_count,
                              updated_at=excluded.updated_at""",
                         (race_date,json.dumps(payload,ensure_ascii=False,separators=(",",":"),default=str),
                          1 if complete else 0,int(payload.get("raceCount") or 0),
                          int(payload.get("detailCount") or 0),int(time.time())))
            conn.commit()
        finally:conn.close()
